//
//  Soccer2.hpp
//  Scramble
//
//  Created by Icarus Black on 8/1/26.
//

#ifndef Soccer2_hpp
#define Soccer2_hpp

#include "TwistWorkSpace.hpp"
#include "TwistShuffle.hpp"
#include "TwistFunctional.hpp"
#include "SoccerTypes.hpp"
#include "SoccerMaskBank.hpp"
#include "PremiumSeedLayout.hpp"
#include "BitPlaneFarm.hpp"
#include "../Public/SoccerDelegate.hpp"

#include "EncryptionLayer.hpp"

#include "Cryptex.hpp"
#include "Jelly.hpp"

#include "TwistExpander_Aldebaran.hpp"
#include "TwistExpander_Altair.hpp"
#include "TwistExpander_Antares.hpp"
#include "TwistExpander_Arcturus.hpp"
#include "TwistExpander_Bellatrix.hpp"
#include "TwistExpander_Betelgeuse.hpp"
#include "TwistExpander_Capella.hpp"
#include "TwistExpander_Castor.hpp"
#include "TwistExpander_Mimosa.hpp"
#include "TwistExpander_Polaris.hpp"
#include "TwistExpander_Pollux.hpp"
#include "TwistExpander_Procyon.hpp"
#include "TwistExpander_Regulus.hpp"
#include "TwistExpander_Rigel.hpp"
#include "TwistExpander_Saiph.hpp"
#include "TwistExpander_Sirius.hpp"
#include "TwistExpander_Vega.hpp"

#include <atomic>
#include <cstddef>
#include <cstdint>

#define SOCCER_EXPANDER_COUNT 16

#define SOCCER_PRELUDE_RAND mCollapseLaneB
#define SOCCER_SCRATCH_WORKER_A mCollapseLaneB
#define SOCCER_WORKER_B mCollapseLaneD

class Soccer2Internal {
public:

    static SoccerDelegate                       *mDelegate;
    
    static std::uint8_t                         mMaterialA[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialB[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialC[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialD[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialE[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialF[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialG[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialH[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialI[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialJ[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialK[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialL[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialM[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialN[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialO[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mMaterialP[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         *mMaterials[16];
    
    static std::uint8_t                         *mClaimedMaterials[16];
    static std::size_t                          mClaimedMaterialCount;
    
    static TwistWorkSpace                       mWorkSpaceA;
    static TwistWorkSpace                       mWorkSpaceB;
    static TwistWorkSpace                       mWorkSpaceC;
    static TwistWorkSpace                       mWorkSpaceD;
    static TwistWorkSpace                       mWorkSpaceE;
    static TwistWorkSpace                       mWorkSpaceF;
    static TwistWorkSpace                       mWorkSpaceG;
    static TwistWorkSpace                       mWorkSpaceH;
    static TwistWorkSpace                       mWorkSpaceI;
    static TwistWorkSpace                       mWorkSpaceJ;
    static TwistWorkSpace                       mWorkSpaceK;
    static TwistWorkSpace                       mWorkSpaceL;
    static TwistWorkSpace                       mWorkSpaceM;
    static TwistWorkSpace                       mWorkSpaceN;
    static TwistWorkSpace                       mWorkSpaceO;
    static TwistWorkSpace                       mWorkSpaceP;
    static TwistWorkSpace                       *mWorkSpaces[16];
    static TwistWorkSpace                       *mClaimedWorkSpaces[16];
    static std::size_t                          mClaimedWorkSpaceCount;
    
    
    static TwistExpander_Betelgeuse             mStarter;
    static TwistExpander_Aldebaran              mAldebaran; // 1
    static TwistExpander_Altair                 mAltair; // 2
    static TwistExpander_Antares                mAntares; // 3
    static TwistExpander_Arcturus               mArcturus; // 4
    static TwistExpander_Bellatrix              mBellatrix; // 5
    static TwistExpander_Capella                mCapella; // 6
    static TwistExpander_Castor                 mCastor; // 7
    static TwistExpander_Mimosa                 mMimosa; // 8
    static TwistExpander_Polaris                mPolaris; // 9
    static TwistExpander_Pollux                 mPollux; // 10
    static TwistExpander_Procyon                mProcyon; // 11
    static TwistExpander_Regulus                mRegulus; // 12
    static TwistExpander_Rigel                  mRigel; // 13
    static TwistExpander_Saiph                  mSaiph; // 14
    static TwistExpander_Sirius                 mSirius; // 15
    static TwistExpander_Vega                   mVega; // 16
    
    static TwistExpander                        *mExpanders[SOCCER_EXPANDER_COUNT];
    static TwistExpander                        *mClaimedExpanders[16];
    static std::size_t                          mClaimedExpanderCount;
    
    static std::uint8_t                         mRandom[S_BLOCK];
    
    static std::uint8_t                         mCollapseLaneA[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mCollapseLaneB[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mCollapseLaneC[SOCCER_BLOCK_SIZE];
    static std::uint8_t                         mCollapseLaneD[SOCCER_BLOCK_SIZE];
    
    static std::uint8_t                         mCondenseLaneA[SOCCER_BLOCK_SIZE_L1];
    static std::uint8_t                         mCondenseLaneB[SOCCER_BLOCK_SIZE_L1];
    static std::uint8_t                         mCondenseLaneC[SOCCER_BLOCK_SIZE_L1];
    static std::uint8_t                         mCondenseLaneD[SOCCER_BLOCK_SIZE_L1];
    
    static std::uint8_t                         mMasks[SoccerMaskBank::mMaskGridWidth];

    // Reusable unit: mBitPlanes[level L3/L2/L1][pass a/b][group a/b/c].
    // Each entry is a mask of 2 or 3 rows; offsets are farmed separately.
    // Base masks repeat across A/B/C, with separate sampled-window offsets.
    // Derived inputs follow each group's bit rotations: L3/L2/L1 use 0/3/6.
    // Fixed experimental inputs; tests may override the mutable copies.
    // Zero clears derived state, but preserves these configuration values.
    static constexpr std::array<std::uint64_t, 3U> kDefaultBitPlaneSelectionValues = {
        0x19ULL, 0xA3ULL, 0x7171ULL // First shuffle, second shuffle, grid-pair rank.
    };
    static std::array<std::uint64_t, 3U>         mBitPlaneSelectionValues;
    static BitPlaneFarm::Bank                   mBitPlanes;
    static void                                FarmBitPlanes();

    struct BitPlaneSamplingInput {
        std::uint8_t mRows[3] = {};
        std::int32_t mRotations[3] = {};
        std::size_t mCount = 0U;
    };
    // [execution-order stage][pass][Frog group]. Each level reserves 48 offsets;
    // only the first triplet is active (24 active offsets per level).
    // Rows are stored in execution orientation, with their original offset pairing.
    static BitPlaneSamplingInput               mBitPlaneInputs[9][2][3];
    static const BitPlaneSamplingInput *        GetBitPlaneInput(std::uint8_t pStage, CipherSamplingBank pBank);
    static std::uint8_t                         GetBitPlaneMask(std::uint8_t pStage, CipherSamplingBank pBank);

    // Two slots per layer; each level stores slot 0 A/B/C, then slot 1 A/B/C.
    // Active plans use slot 0; slot 1 remains reserved for experiments.
    static constexpr std::size_t                kRotationsPerLayer = 2U;
    static constexpr std::size_t                kRotationsPerLevel = 3U * kRotationsPerLayer;
    static constexpr std::size_t                kByteRotationCount = 3U * kRotationsPerLevel;
    static std::int32_t                         mRotationsByteL3[kRotationsPerLevel];
    static std::int32_t                         mRotationsByteL2[kRotationsPerLevel];
    static std::int32_t                         mRotationsByteL1[kRotationsPerLevel];

    // One shared permutation, then 256 globally distinct base windows.
    // Every accepted window blocks itself and both kinds of complement:
    // 4096-w for whole-window rotations, 4095-w for nonzero byte offsets.
    static constexpr std::size_t                kRotationWindowBaseCount = 4095U;
    static constexpr std::size_t                kRotationWindowListCount = 64U;
    static constexpr std::size_t                kRotationWindowCount = 4U * kRotationWindowListCount;
    static constexpr std::size_t                kRotationWindowBlockCapacity = 3U * kRotationWindowCount;
    static std::uint16_t                        mRotationWindowBase[kRotationWindowBaseCount];
    static std::uint16_t                        mRotationWindow[kRotationWindowCount];
    static std::uint16_t                        mRotationWindowBlockList[kRotationWindowBlockCapacity];
    static std::size_t                          mRotationWindowBlockListCount;
    static std::size_t                          mRotationWindowBaseReadCount;
    // Disjoint quarters of mRotationWindow: L1, L2, L3, Free.
    static std::uint16_t                        mRotationWindowListL1[kRotationWindowListCount];
    static std::uint16_t                        mRotationWindowListL2[kRotationWindowListCount];
    static std::uint16_t                        mRotationWindowListL3[kRotationWindowListCount];
    // Byte rotations stored on the L3 ring; wrap to the target level on use.
    static std::int32_t                         mRotationWindowListFree[kRotationWindowListCount];
    static void                                FarmRotationWindows();
    static void                                SelectRotationWindows();
    static void                                AssignRotationWindows();

    // Planet/Frog, Moon/Toad, Star/Newt. A..I are the stages
    // L3A,L2A,L1A,L3B,L2B,L1B,L3C,L2C,L1C. Each 3x3 group covers
    // rows 0..7 once per layer AND once per family. Prefix length is mCount.
    static std::uint8_t                         mCipherRowsPlanetA[2];
    static std::uint8_t                         mCipherRowsPlanetB[3];
    static std::uint8_t                         mCipherRowsPlanetC[3];
    static std::uint8_t                         mCipherRowsPlanetD[3];
    static std::uint8_t                         mCipherRowsPlanetE[3];
    static std::uint8_t                         mCipherRowsPlanetF[2];
    static std::uint8_t                         mCipherRowsPlanetG[3];
    static std::uint8_t                         mCipherRowsPlanetH[2];
    static std::uint8_t                         mCipherRowsPlanetI[3];

    static std::int32_t                         mRotationsPlanetA[2]; // L3A: windows [1, 16,383]
    static std::int32_t                         mRotationsPlanetB[3]; // L2A: windows [1, 8,191]
    static std::int32_t                         mRotationsPlanetC[3]; // L1A: windows [1, 4,095]
    static std::int32_t                         mRotationsPlanetD[3]; // L3B: windows [1, 16,383]
    static std::int32_t                         mRotationsPlanetE[3]; // L2B: windows [1, 8,191]
    static std::int32_t                         mRotationsPlanetF[2]; // L1B: windows [1, 4,095]
    static std::int32_t                         mRotationsPlanetG[3]; // L3C: windows [1, 16,383]
    static std::int32_t                         mRotationsPlanetH[2]; // L2C: windows [1, 8,191]
    static std::int32_t                         mRotationsPlanetI[3]; // L1C: windows [1, 4,095]

    static std::uint8_t                         mCipherRowsMoonA[3];
    static std::uint8_t                         mCipherRowsMoonB[2];
    static std::uint8_t                         mCipherRowsMoonC[3];
    static std::uint8_t                         mCipherRowsMoonD[2];
    static std::uint8_t                         mCipherRowsMoonE[3];
    static std::uint8_t                         mCipherRowsMoonF[3];
    static std::uint8_t                         mCipherRowsMoonG[3];
    static std::uint8_t                         mCipherRowsMoonH[3];
    static std::uint8_t                         mCipherRowsMoonI[2];

    static std::int32_t                         mRotationsMoonA[3]; // L3A: windows [1, 16,383]
    static std::int32_t                         mRotationsMoonB[2]; // L2A: windows [1, 8,191]
    static std::int32_t                         mRotationsMoonC[3]; // L1A: windows [1, 4,095]
    static std::int32_t                         mRotationsMoonD[2]; // L3B: windows [1, 16,383]
    static std::int32_t                         mRotationsMoonE[3]; // L2B: windows [1, 8,191]
    static std::int32_t                         mRotationsMoonF[3]; // L1B: windows [1, 4,095]
    static std::int32_t                         mRotationsMoonG[3]; // L3C: windows [1, 16,383]
    static std::int32_t                         mRotationsMoonH[3]; // L2C: windows [1, 8,191]
    static std::int32_t                         mRotationsMoonI[2]; // L1C: windows [1, 4,095]

    static std::uint8_t                         mCipherRowsStarA[3];
    static std::uint8_t                         mCipherRowsStarB[3];
    static std::uint8_t                         mCipherRowsStarC[2];
    static std::uint8_t                         mCipherRowsStarD[3];
    static std::uint8_t                         mCipherRowsStarE[2];
    static std::uint8_t                         mCipherRowsStarF[3];
    static std::uint8_t                         mCipherRowsStarG[2];
    static std::uint8_t                         mCipherRowsStarH[3];
    static std::uint8_t                         mCipherRowsStarI[3];

    static std::int32_t                         mRotationsStarA[3]; // L3A: windows [1, 16,383]
    static std::int32_t                         mRotationsStarB[3]; // L2A: windows [1, 8,191]
    static std::int32_t                         mRotationsStarC[2]; // L1A: windows [1, 4,095]
    static std::int32_t                         mRotationsStarD[3]; // L3B: windows [1, 16,383]
    static std::int32_t                         mRotationsStarE[2]; // L2B: windows [1, 8,191]
    static std::int32_t                         mRotationsStarF[3]; // L1B: windows [1, 4,095]
    static std::int32_t                         mRotationsStarG[2]; // L3C: windows [1, 16,383]
    static std::int32_t                         mRotationsStarH[3]; // L2C: windows [1, 8,191]
    static std::int32_t                         mRotationsStarI[3]; // L1C: windows [1, 4,095]

    struct SamplingInput {
        std::uint8_t *mRows;
        std::int32_t *mRotations;
        std::size_t mCount;
        template <std::size_t N>
        constexpr SamplingInput(std::uint8_t (&pRows)[N], std::int32_t (&pRotations)[N])
            : mRows(pRows), mRotations(pRotations), mCount(N) {
            static_assert(N == 2U || N == 3U);
        }
    };
    static constexpr std::size_t                kSamplingStageCount = 9U;
    static constexpr std::size_t                kSamplingWordsPerGroup = 21U;
    static const SamplingInput                  mPlanetInputs[kSamplingStageCount];
    static const SamplingInput                  mMoonInputs[kSamplingStageCount];
    static const SamplingInput                  mStarInputs[kSamplingStageCount];


    static std::uint8_t                         *mSources[16];
    static CipherType                           mCiphersMutate[32];
    static CipherType                           mCiphersPrimaryMovers[32];
    static CipherType                           mCiphersSecondaryMovers[32];
    

    static std::uint8_t                         *mCross[4][16];
    static std::uint8_t                         *mCrossPool[16][64];
    static std::size_t                          mCrossPoolCount[16];
    static std::uint8_t                          mCrossPermutations[16][64];
    
    static bool                                 mClaimed[SOCCER_EXPANDER_COUNT];
    
    static Cryptex9                             mCryptex9;
    
    static std::uint8_t                         *mShuffleMaterials[16];
    static TwistExpander                        *mShuffleExpanders[SOCCER_EXPANDER_COUNT];
    static TwistWorkSpace                       *mShuffleWorkSpaces[16];
    
    static EncryptionStrength                   mStrength;
    static std::size_t                          mMaskCursor;
    
    static uint32_t                             mTestBlockLength;
    
    // 3,024 seed-source words, split into two shuffled streams of 1,512.
    static constexpr std::size_t                kSeedIndexCount = PremiumSeedLayout::kSeedWordsPerHalf;
    static std::uint16_t                        mIndexListA[kSeedIndexCount];
    static std::uint16_t                        mIndexListB[kSeedIndexCount];

    // 63 words, used exclusively for the three row-family grids and row orders.
    static constexpr std::size_t                kPremiumSeedWordCount = PremiumSeedLayout::kPremiumWords;
    static std::uint64_t                        mPremiumSeed[kPremiumSeedWordCount];
    static std::uint64_t                        mPlanSelectionValue;
    static std::uint64_t                        ReadShuffleWord(std::size_t pIndex);

    static std::size_t                          mMaterialIndex;
    static std::size_t                          mMaterialQuarter;
    
    static void                                 Zero();

    static void                                 SetDelegate(SoccerDelegate *pDelegate);
    
    static void                                 ConfigureTestBuffers(std::uint32_t pTestBlockLength); // SOCCER_BLOCK_SIZE (L3 size)
    
    // Optional caller-owned flag; keep alive until return and only set true
    // during an attempt. Polls use relaxed loads and never modify the flag.
    static bool                                 AttemptSeed_Encrypt(EncryptionStrength pStrength,
                                                                    std::uint8_t *pPassword,
                                                                    std::size_t pPasswordByteLength,
                                                                    std::uint64_t pNonce,
                                                                    std::uint32_t *pAckWord,
                                                                    std::uint64_t pVersion,
                                                                    const std::atomic<bool> *pCancelled);
    
    static bool                                 AttemptSeed_Decrypt(EncryptionStrength pStrength,
                                                                    std::uint8_t *pPassword,
                                                                    std::size_t pPasswordByteLength,
                                                                    std::uint64_t pNonce,
                                                                    std::uint32_t pAckWord,
                                                                    std::uint64_t pVersion,
                                                                    const std::atomic<bool> *pCancelled);
    
    static bool                                 EncryptBlock(std::uint8_t *pSource,
                                                             std::uint8_t *pDestination);
    static bool                                 DecryptBlock(std::uint8_t *pSource,
                                                             std::uint8_t *pDestination);
    
    static void                                 InitializeCiphers();
    static void                                 InitializeExpanders();
    static void                                 InitializeWorkSpaces();
    static void                                 InitializeMaterials();
    
    static void                                 UnrollNonceAndPasswordToScratch_Test(std::uint8_t *pPassword,
                                                                                     std::size_t pPasswordByteLength,
                                                                                     std::uint64_t pNonce);
    static void                                 UnrollNonceAndPasswordToScratch_Regular(std::uint8_t *pPassword,
                                                                                        std::size_t pPasswordByteLength,
                                                                                        std::uint64_t pNonce);
    
    
    static bool                                 SeedPrelude_Test(std::uint8_t *pPassword,
                                                                 std::size_t pPasswordByteLength,
                                                                 std::uint64_t pNonce);
    static void                                 SeedPrelude_Regular_A(std::uint8_t *pPassword,
                                                                      std::size_t pPasswordByteLength,
                                                                      std::uint64_t pNonce);
    static void                                 SeedPrelude_Regular_B(std::uint64_t pNonce, MUTABLE_PARAMS);
    static void                                 SeedPrelude_Regular_C();
    
    
    static bool                                 SeedPrologue_Regular_A(std::uint8_t *pPassword,
                                                                       std::size_t pPasswordByteLength,
                                                                       std::uint64_t pNonce,
                                                                       MUTABLE_PARAMS,
                                                                       const std::atomic<bool> *pCancelled);
    static void                                 SeedPrologue_Regular_B();
    static bool                                 SeedPrologue_Regular_C(std::uint32_t *pAckWord,
                                                                       bool pForwardDeploy,
                                                                       MUTABLE_PARAMS,
                                                                       const std::atomic<bool> *pCancelled);
    static bool                                 SeedPrologue_Regular_D(MUTABLE_PARAMS,
                                                                       const std::atomic<bool> *pCancelled);
    
    
    static bool                                 TwistRound(std::size_t pBlockIndex,
                                                           bool pIsWarmUpRound,
                                                           MUTABLE_PARAMS,
                                                           const std::atomic<bool> *pCancelled);
    
    
    static void                                 ArrangeCrossPool(std::size_t pComplexity);
    static void                                 InitializeCrossPermutations();
    static void                                 BuildCrossPool_WarmUp1(std::size_t pComplexity,
                                                                       std::size_t pCurrentByteIndex);
    static void                                 BuildCrossPool_WarmUp2(std::size_t pComplexity,
                                                                       std::size_t pPreviousByteIndex,
                                                                       std::size_t pCurrentByteIndex);
    static void                                 BuildCrossPool_WarmUp4(std::size_t pComplexity,
                                                                       std::size_t pThreeRoundsBackByteIndex,
                                                                       std::size_t pTwoRoundsBackByteIndex,
                                                                       std::size_t pOneRoundBackByteIndex);
    static void                                 BuildCrossPool_Regular(std::size_t pComplexity,
                                                                      std::size_t pFourRoundsBackByteIndex,
                                                                      std::size_t pThreeRoundsBackByteIndex,
                                                                      std::size_t pTwoRoundsBackByteIndex,
                                                                      std::size_t pOneRoundBackByteIndex);
    
    static void                                 SeedEpilogue_Regular_A();
    static void                                 SeedEpilogue_Regular_B();
    static void                                 SeedEpilogue_Regular_C();
    static bool                                 SeedEpilogue_Regular_D();
    
    
    
    static void                                 Shuffle_MEWBlockZero(std::uint8_t *pMaterial);
    
    // MAT WS CI EX MAS SOR CRO1 CRO2 CRO3 CRO4
    static void                                 Shuffle_CROWSCIMASSORMATEX();
    static void                                 Shuffle_CROPER(std::size_t pPermutationCount);
    
    static void                                 FoldMaterialsIntoRandomForBlock_4(std::size_t pBlockIndex);
    static void                                 FoldMaterialsIntoRandomForBlock_8(std::size_t pBlockIndex);
    static void                                 FoldMaterialsIntoRandomForBlock_16(std::size_t pBlockIndex);
    
    static Cipher                               *GenerateCipher(CipherType pType, std::uint8_t pStage,
                                                                CipherSamplingBank pSamplingBank = CipherSamplingBank::kByCipherType,
                                                                std::size_t pRotationIndex = 0U);
    static std::uint8_t                         *PopLaneS3();
    static std::uint8_t                         *PopLaneS2();
    static std::uint8_t                         *PopLaneS1();
    static std::uint8_t                         PopMask();
    static std::int32_t                         GetByteRotationForStage(std::uint8_t pStage,
                                                                       std::size_t pRotationIndex = 0U);

private:
    static std::size_t                          mSeedProgressCompleted;
    static std::size_t                          mSeedProgressTotal;

    static void                                 BeginSeedProgress(EncryptionStrength pStrength);
    static void                                 AdvanceSeedProgress(std::size_t pCost);
    static bool                                 FinishSeedProgress(bool pSuccess);
    
};

#ifndef SOCCER2_DISABLE_COMPAT_ALIAS
using Soccer2 = Soccer2Internal;
#endif

#endif /* Soccer2_hpp */
