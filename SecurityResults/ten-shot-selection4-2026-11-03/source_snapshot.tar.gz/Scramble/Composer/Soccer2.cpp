//
//  Soccer2.cpp
//  Scramble
//
//  Created by Icarus Black on 8/1/26.
//

#include "Soccer2.hpp"
#include "SoccerFolding.hpp"
#include "TwistMix32.hpp"
#include "TwistMix64.hpp"
#include "EncryptionPlan.hpp"
#include "SoccerMaskBank.hpp"
#include "SamplingTriplet.hpp"

#include <cstdlib>
#include <cassert>

#include <algorithm>
#include <cstring>

#define BLOCK_COUNT (SOCCER_BLOCK_SIZE / S_BLOCK)

#define COMPLEXITY_STRONG 16
#define COMPLEXITY_NORMAL 8
#define COMPLEXITY_WEAK 4

#define WARM_UP_ROUNDS 5
#define WARM_UP_BLOCKS (WARM_UP_ROUNDS + 1)

#define READ_IN_MUTABLE_PARAMS_INTERNAL \
    std::uint64_t aIngress = *pIngress; \
    std::uint64_t aCarry = *pCarry; \
    std::uint64_t aWandererA = *pWandererA; \
    std::uint64_t aWandererB = *pWandererB; \
    std::uint64_t aWandererC = *pWandererC; \
    std::uint64_t aWandererD = *pWandererD; \
    std::uint64_t aWandererE = *pWandererE; \
    std::uint64_t aWandererF = *pWandererF; \
    std::uint64_t aWandererG = *pWandererG; \
    std::uint64_t aWandererH = *pWandererH; \
    std::uint64_t aWandererI = *pWandererI; \
    std::uint64_t aWandererJ = *pWandererJ; \
    std::uint64_t aWandererK = *pWandererK

namespace {

constexpr std::uint8_t kStageL3A = 0U;
constexpr std::uint8_t kStageL2A = 1U;
constexpr std::uint8_t kStageL1A = 2U;
constexpr std::uint8_t kStageL3B = 3U;
constexpr std::uint8_t kStageL2B = 4U;
constexpr std::uint8_t kStageL1B = 5U;
constexpr std::uint8_t kStageL3C = 6U;
constexpr std::uint8_t kStageL2C = 7U;
constexpr std::uint8_t kStageL1C = 8U;

constexpr std::size_t kExpanderSeedCost = 3U;
constexpr std::size_t kExpanderTwistCost = 1U;
constexpr std::size_t kSeedEpilogueCost = 1U;

} // namespace

static_assert((SOCCER_BLOCK_SIZE % S_BLOCK) == 0U);
static_assert(BLOCK_COUNT >= WARM_UP_BLOCKS);

SoccerDelegate                              *Soccer2::mDelegate = nullptr;
std::size_t                                 Soccer2::mSeedProgressCompleted = 0U;
std::size_t                                 Soccer2::mSeedProgressTotal = 0U;

std::uint8_t                                Soccer2::mMaterialA[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialB[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialC[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialD[SOCCER_BLOCK_SIZE];

std::uint8_t                                Soccer2::mMaterialE[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialF[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialG[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialH[SOCCER_BLOCK_SIZE];

std::uint8_t                                Soccer2::mMaterialI[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialJ[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialK[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialL[SOCCER_BLOCK_SIZE];

std::uint8_t                                Soccer2::mMaterialM[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialN[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialO[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mMaterialP[SOCCER_BLOCK_SIZE];

TwistExpander_Betelgeuse                    Soccer2::mStarter;

TwistExpander_Aldebaran                     Soccer2::mAldebaran; // 1
TwistExpander_Altair                        Soccer2::mAltair; // 2
TwistExpander_Antares                       Soccer2::mAntares; // 3
TwistExpander_Arcturus                      Soccer2::mArcturus; // 4
TwistExpander_Bellatrix                     Soccer2::mBellatrix; // 5
TwistExpander_Capella                       Soccer2::mCapella; // 6
TwistExpander_Castor                        Soccer2::mCastor; // 7
TwistExpander_Mimosa                        Soccer2::mMimosa; // 8
TwistExpander_Polaris                       Soccer2::mPolaris; // 9
TwistExpander_Pollux                        Soccer2::mPollux; // 10
TwistExpander_Procyon                       Soccer2::mProcyon; // 11
TwistExpander_Regulus                       Soccer2::mRegulus; // 12
TwistExpander_Rigel                         Soccer2::mRigel; // 13
TwistExpander_Saiph                         Soccer2::mSaiph; // 14
TwistExpander_Sirius                        Soccer2::mSirius; // 15
TwistExpander_Vega                          Soccer2::mVega; // 16

TwistWorkSpace                              Soccer2::mWorkSpaceA;
TwistWorkSpace                              Soccer2::mWorkSpaceB;
TwistWorkSpace                              Soccer2::mWorkSpaceC;
TwistWorkSpace                              Soccer2::mWorkSpaceD;
TwistWorkSpace                              Soccer2::mWorkSpaceE;
TwistWorkSpace                              Soccer2::mWorkSpaceF;
TwistWorkSpace                              Soccer2::mWorkSpaceG;
TwistWorkSpace                              Soccer2::mWorkSpaceH;
TwistWorkSpace                              Soccer2::mWorkSpaceI;
TwistWorkSpace                              Soccer2::mWorkSpaceJ;
TwistWorkSpace                              Soccer2::mWorkSpaceK;
TwistWorkSpace                              Soccer2::mWorkSpaceL;
TwistWorkSpace                              Soccer2::mWorkSpaceM;
TwistWorkSpace                              Soccer2::mWorkSpaceN;
TwistWorkSpace                              Soccer2::mWorkSpaceO;
TwistWorkSpace                              Soccer2::mWorkSpaceP;

std::uint8_t                                Soccer2::mRandom[S_BLOCK];

std::uint8_t                                Soccer2::mCollapseLaneA[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mCollapseLaneB[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mCollapseLaneC[SOCCER_BLOCK_SIZE];
std::uint8_t                                Soccer2::mCollapseLaneD[SOCCER_BLOCK_SIZE];

std::uint8_t                                Soccer2::mCondenseLaneA[SOCCER_BLOCK_SIZE_L1];
std::uint8_t                                Soccer2::mCondenseLaneB[SOCCER_BLOCK_SIZE_L1];
std::uint8_t                                Soccer2::mCondenseLaneC[SOCCER_BLOCK_SIZE_L1];
std::uint8_t                                Soccer2::mCondenseLaneD[SOCCER_BLOCK_SIZE_L1];

std::uint16_t                                 Soccer2::mIndexListA[kSeedIndexCount];
std::uint16_t                                 Soccer2::mIndexListB[kSeedIndexCount];

std::uint64_t                               Soccer2::mPremiumSeed[kPremiumSeedWordCount];

std::uint8_t                                Soccer2::mMasks[SoccerMaskBank::mMaskGridWidth];
BitPlaneFarm::Bank                          Soccer2::mBitPlanes{};
Soccer2::BitPlaneSamplingInput              Soccer2::mBitPlaneInputs[9][2][3]{};
std::array<std::uint64_t, 3U>                Soccer2::mBitPlaneSelectionValues = kDefaultBitPlaneSelectionValues;
std::uint64_t                              Soccer2::mPlanSelectionValue;

std::int32_t                                Soccer2::mRotationsByteL3[Soccer2::kRotationsPerLevel];
std::int32_t                                Soccer2::mRotationsByteL2[Soccer2::kRotationsPerLevel];
std::int32_t                                Soccer2::mRotationsByteL1[Soccer2::kRotationsPerLevel];

std::uint16_t                               Soccer2::mRotationWindowBase[kRotationWindowBaseCount];
std::uint16_t                               Soccer2::mRotationWindow[kRotationWindowCount];
std::uint16_t                               Soccer2::mRotationWindowBlockList[kRotationWindowBlockCapacity];
std::size_t                                 Soccer2::mRotationWindowBlockListCount;
std::size_t                                 Soccer2::mRotationWindowBaseReadCount;
std::uint16_t                               Soccer2::mRotationWindowListL1[kRotationWindowListCount];
std::uint16_t                               Soccer2::mRotationWindowListL2[kRotationWindowListCount];
std::uint16_t                               Soccer2::mRotationWindowListL3[kRotationWindowListCount];
std::int32_t                                Soccer2::mRotationWindowListFree[kRotationWindowListCount];

std::uint8_t                                Soccer2::mCipherRowsPlanetA[2];
std::uint8_t                                Soccer2::mCipherRowsPlanetB[3];
std::uint8_t                                Soccer2::mCipherRowsPlanetC[3];
std::uint8_t                                Soccer2::mCipherRowsPlanetD[3];
std::uint8_t                                Soccer2::mCipherRowsPlanetE[3];
std::uint8_t                                Soccer2::mCipherRowsPlanetF[2];
std::uint8_t                                Soccer2::mCipherRowsPlanetG[3];
std::uint8_t                                Soccer2::mCipherRowsPlanetH[2];
std::uint8_t                                Soccer2::mCipherRowsPlanetI[3];
std::int32_t                                Soccer2::mRotationsPlanetA[2];
std::int32_t                                Soccer2::mRotationsPlanetB[3];
std::int32_t                                Soccer2::mRotationsPlanetC[3];
std::int32_t                                Soccer2::mRotationsPlanetD[3];
std::int32_t                                Soccer2::mRotationsPlanetE[3];
std::int32_t                                Soccer2::mRotationsPlanetF[2];
std::int32_t                                Soccer2::mRotationsPlanetG[3];
std::int32_t                                Soccer2::mRotationsPlanetH[2];
std::int32_t                                Soccer2::mRotationsPlanetI[3];
const Soccer2::SamplingInput                Soccer2::mPlanetInputs[Soccer2::kSamplingStageCount] = {
    {mCipherRowsPlanetA, mRotationsPlanetA},
    {mCipherRowsPlanetB, mRotationsPlanetB},
    {mCipherRowsPlanetC, mRotationsPlanetC},
    {mCipherRowsPlanetD, mRotationsPlanetD},
    {mCipherRowsPlanetE, mRotationsPlanetE},
    {mCipherRowsPlanetF, mRotationsPlanetF},
    {mCipherRowsPlanetG, mRotationsPlanetG},
    {mCipherRowsPlanetH, mRotationsPlanetH},
    {mCipherRowsPlanetI, mRotationsPlanetI},
};

std::uint8_t                                Soccer2::mCipherRowsMoonA[3];
std::uint8_t                                Soccer2::mCipherRowsMoonB[2];
std::uint8_t                                Soccer2::mCipherRowsMoonC[3];
std::uint8_t                                Soccer2::mCipherRowsMoonD[2];
std::uint8_t                                Soccer2::mCipherRowsMoonE[3];
std::uint8_t                                Soccer2::mCipherRowsMoonF[3];
std::uint8_t                                Soccer2::mCipherRowsMoonG[3];
std::uint8_t                                Soccer2::mCipherRowsMoonH[3];
std::uint8_t                                Soccer2::mCipherRowsMoonI[2];
std::int32_t                                Soccer2::mRotationsMoonA[3];
std::int32_t                                Soccer2::mRotationsMoonB[2];
std::int32_t                                Soccer2::mRotationsMoonC[3];
std::int32_t                                Soccer2::mRotationsMoonD[2];
std::int32_t                                Soccer2::mRotationsMoonE[3];
std::int32_t                                Soccer2::mRotationsMoonF[3];
std::int32_t                                Soccer2::mRotationsMoonG[3];
std::int32_t                                Soccer2::mRotationsMoonH[3];
std::int32_t                                Soccer2::mRotationsMoonI[2];
const Soccer2::SamplingInput                Soccer2::mMoonInputs[Soccer2::kSamplingStageCount] = {
    {mCipherRowsMoonA, mRotationsMoonA},
    {mCipherRowsMoonB, mRotationsMoonB},
    {mCipherRowsMoonC, mRotationsMoonC},
    {mCipherRowsMoonD, mRotationsMoonD},
    {mCipherRowsMoonE, mRotationsMoonE},
    {mCipherRowsMoonF, mRotationsMoonF},
    {mCipherRowsMoonG, mRotationsMoonG},
    {mCipherRowsMoonH, mRotationsMoonH},
    {mCipherRowsMoonI, mRotationsMoonI},
};

std::uint8_t                                Soccer2::mCipherRowsStarA[3];
std::uint8_t                                Soccer2::mCipherRowsStarB[3];
std::uint8_t                                Soccer2::mCipherRowsStarC[2];
std::uint8_t                                Soccer2::mCipherRowsStarD[3];
std::uint8_t                                Soccer2::mCipherRowsStarE[2];
std::uint8_t                                Soccer2::mCipherRowsStarF[3];
std::uint8_t                                Soccer2::mCipherRowsStarG[2];
std::uint8_t                                Soccer2::mCipherRowsStarH[3];
std::uint8_t                                Soccer2::mCipherRowsStarI[3];
std::int32_t                                Soccer2::mRotationsStarA[3];
std::int32_t                                Soccer2::mRotationsStarB[3];
std::int32_t                                Soccer2::mRotationsStarC[2];
std::int32_t                                Soccer2::mRotationsStarD[3];
std::int32_t                                Soccer2::mRotationsStarE[2];
std::int32_t                                Soccer2::mRotationsStarF[3];
std::int32_t                                Soccer2::mRotationsStarG[2];
std::int32_t                                Soccer2::mRotationsStarH[3];
std::int32_t                                Soccer2::mRotationsStarI[3];
const Soccer2::SamplingInput                Soccer2::mStarInputs[Soccer2::kSamplingStageCount] = {
    {mCipherRowsStarA, mRotationsStarA},
    {mCipherRowsStarB, mRotationsStarB},
    {mCipherRowsStarC, mRotationsStarC},
    {mCipherRowsStarD, mRotationsStarD},
    {mCipherRowsStarE, mRotationsStarE},
    {mCipherRowsStarF, mRotationsStarF},
    {mCipherRowsStarG, mRotationsStarG},
    {mCipherRowsStarH, mRotationsStarH},
    {mCipherRowsStarI, mRotationsStarI},
};

std::uint8_t                                *Soccer2::mMaterials[16];
TwistExpander                               *Soccer2::mExpanders[SOCCER_EXPANDER_COUNT];
TwistWorkSpace                              *Soccer2::mWorkSpaces[16];
std::uint8_t                                *Soccer2::mSources[16];
std::uint8_t                                *Soccer2::mCross[4][16];

std::uint8_t                                *Soccer2::mCrossPool[16][64];
std::size_t                                 Soccer2::mCrossPoolCount[16];
std::uint8_t                                 Soccer2::mCrossPermutations[16][64];

bool                                        Soccer2::mClaimed[SOCCER_EXPANDER_COUNT];

TwistExpander                               *Soccer2::mClaimedExpanders[16];
std::size_t                                 Soccer2::mClaimedExpanderCount;

std::uint8_t                                *Soccer2::mClaimedMaterials[16];
std::size_t                                 Soccer2::mClaimedMaterialCount;

TwistWorkSpace                              *Soccer2::mClaimedWorkSpaces[16];
std::size_t                                 Soccer2::mClaimedWorkSpaceCount;

Cryptex9                                    Soccer2::mCryptex9;

std::uint8_t                                *Soccer2::mShuffleMaterials[16];
TwistExpander                               *Soccer2::mShuffleExpanders[SOCCER_EXPANDER_COUNT];
TwistWorkSpace                              *Soccer2::mShuffleWorkSpaces[16];

CipherType                                  Soccer2::mCiphersMutate[32];
CipherType                                  Soccer2::mCiphersPrimaryMovers[32];
CipherType                                  Soccer2::mCiphersSecondaryMovers[32];

EncryptionStrength                          Soccer2::mStrength = EncryptionStrength::kNormal;

uint32_t                                    Soccer2::mTestBlockLength = SOCCER_BLOCK_SIZE;

std::size_t                                 Soccer2::mMaterialIndex = 0;
std::size_t                                 Soccer2::mMaterialQuarter = 0;

std::size_t                                 Soccer2::mMaskCursor = 0;

void Soccer2::InitializeCiphers() {
    // Mutate ciphers: 13 password, 10 jump, 9 pepper.
    // Slots 0-3: PasswordAddCipher (4).
    mCiphersMutate[ 0] = CipherType::kPasswordAddCipher;
    mCiphersMutate[ 1] = CipherType::kPasswordAddCipher;
    mCiphersMutate[ 2] = CipherType::kPasswordAddCipher;
    mCiphersMutate[ 3] = CipherType::kPasswordAddCipher;

    // Slots 4-7: PasswordXORCipher (4).
    mCiphersMutate[ 4] = CipherType::kPasswordXORCipher;
    mCiphersMutate[ 5] = CipherType::kPasswordXORCipher;
    mCiphersMutate[ 6] = CipherType::kPasswordXORCipher;
    mCiphersMutate[ 7] = CipherType::kPasswordXORCipher;

    // Slots 8-11: PasswordSubtractCipher (4).
    mCiphersMutate[ 8] = CipherType::kPasswordSubtractCipher;
    mCiphersMutate[ 9] = CipherType::kPasswordSubtractCipher;
    mCiphersMutate[10] = CipherType::kPasswordSubtractCipher;
    mCiphersMutate[11] = CipherType::kPasswordSubtractCipher;

    // Slots 12-14: PasswordJumpXORCipher (3).
    mCiphersMutate[12] = CipherType::kPasswordJumpXORCipher;
    mCiphersMutate[13] = CipherType::kPasswordJumpXORCipher;
    mCiphersMutate[14] = CipherType::kPasswordJumpXORCipher;

    // Slots 15-17: PasswordJumpAddCipher (3).
    mCiphersMutate[15] = CipherType::kPasswordJumpAddCipher;
    mCiphersMutate[16] = CipherType::kPasswordJumpAddCipher;
    mCiphersMutate[17] = CipherType::kPasswordJumpAddCipher;

    // Slots 18-20: PasswordJumpSubtractCipher (3).
    mCiphersMutate[18] = CipherType::kPasswordJumpSubtractCipher;
    mCiphersMutate[19] = CipherType::kPasswordJumpSubtractCipher;
    mCiphersMutate[20] = CipherType::kPasswordJumpSubtractCipher;

    // Slots 21-23: PepperNoiseXORCipher (3).
    mCiphersMutate[21] = CipherType::kPepperNoiseXORCipher;
    mCiphersMutate[22] = CipherType::kPepperNoiseXORCipher;
    mCiphersMutate[23] = CipherType::kPepperNoiseXORCipher;

    // Slots 24-26: PepperJumpNoiseXORCipher (3).
    mCiphersMutate[24] = CipherType::kPepperJumpNoiseXORCipher;
    mCiphersMutate[25] = CipherType::kPepperJumpNoiseXORCipher;
    mCiphersMutate[26] = CipherType::kPepperJumpNoiseXORCipher;

    // Slots 27-29: PepperDualJumpNoiseXORCipher (3).
    mCiphersMutate[27] = CipherType::kPepperDualJumpNoiseXORCipher;
    mCiphersMutate[28] = CipherType::kPepperDualJumpNoiseXORCipher;
    mCiphersMutate[29] = CipherType::kPepperDualJumpNoiseXORCipher;

    mCiphersMutate[30] = CipherType::kPasswordAddCipher;

    mCiphersMutate[31] = CipherType::kPasswordJumpAddCipher;

    // Primary movers: 12 reverse, 10 splint-32, 10 splint-64.
    // Slots 0-11: ReverseMaskCipher (12).
    mCiphersPrimaryMovers[ 0] = CipherType::kReverseMaskCipher;
    mCiphersPrimaryMovers[ 1] = CipherType::kReverseMaskCipher;
    mCiphersPrimaryMovers[ 2] = CipherType::kReverseMaskCipher;
    mCiphersPrimaryMovers[ 3] = CipherType::kReverseMaskCipher;
    mCiphersPrimaryMovers[ 4] = CipherType::kReverseMaskCipher;
    mCiphersPrimaryMovers[ 5] = CipherType::kReverseMaskCipher;
    mCiphersPrimaryMovers[ 6] = CipherType::kReverseMaskCipher;
    mCiphersPrimaryMovers[ 7] = CipherType::kReverseMaskCipher;
    mCiphersPrimaryMovers[ 8] = CipherType::kReverseMaskCipher;
    mCiphersPrimaryMovers[ 9] = CipherType::kReverseMaskCipher;
    mCiphersPrimaryMovers[10] = CipherType::kReverseMaskCipher;
    mCiphersPrimaryMovers[11] = CipherType::kReverseMaskCipher;

    // Slots 12-21: SplintMaskBlockCipher32 (10).
    mCiphersPrimaryMovers[12] = CipherType::kSplintMaskBlockCipher32;
    mCiphersPrimaryMovers[13] = CipherType::kSplintMaskBlockCipher32;
    mCiphersPrimaryMovers[14] = CipherType::kSplintMaskBlockCipher32;
    mCiphersPrimaryMovers[15] = CipherType::kSplintMaskBlockCipher32;
    mCiphersPrimaryMovers[16] = CipherType::kSplintMaskBlockCipher32;
    mCiphersPrimaryMovers[17] = CipherType::kSplintMaskBlockCipher32;
    mCiphersPrimaryMovers[18] = CipherType::kSplintMaskBlockCipher32;
    mCiphersPrimaryMovers[19] = CipherType::kSplintMaskBlockCipher32;
    mCiphersPrimaryMovers[20] = CipherType::kSplintMaskBlockCipher32;
    mCiphersPrimaryMovers[21] = CipherType::kSplintMaskBlockCipher32;

    // Slots 22-31: SplintMaskBlockCipher64 (10).
    mCiphersPrimaryMovers[22] = CipherType::kSplintMaskBlockCipher64;
    mCiphersPrimaryMovers[23] = CipherType::kSplintMaskBlockCipher64;
    mCiphersPrimaryMovers[24] = CipherType::kSplintMaskBlockCipher64;
    mCiphersPrimaryMovers[25] = CipherType::kSplintMaskBlockCipher64;
    mCiphersPrimaryMovers[26] = CipherType::kSplintMaskBlockCipher64;
    mCiphersPrimaryMovers[27] = CipherType::kSplintMaskBlockCipher64;
    mCiphersPrimaryMovers[28] = CipherType::kSplintMaskBlockCipher64;
    mCiphersPrimaryMovers[29] = CipherType::kSplintMaskBlockCipher64;
    mCiphersPrimaryMovers[30] = CipherType::kSplintMaskBlockCipher64;
    mCiphersPrimaryMovers[31] = CipherType::kSplintMaskBlockCipher64;

    // Secondary movers: 7 of each block mover, 4 invert.
    // Slots 0-6: RippleMaskBlockCipher32 (7).
    mCiphersSecondaryMovers[ 0] = CipherType::kRippleMaskBlockCipher32;
    mCiphersSecondaryMovers[ 1] = CipherType::kRippleMaskBlockCipher32;
    mCiphersSecondaryMovers[ 2] = CipherType::kRippleMaskBlockCipher32;
    mCiphersSecondaryMovers[ 3] = CipherType::kRippleMaskBlockCipher32;
    mCiphersSecondaryMovers[ 4] = CipherType::kRippleMaskBlockCipher32;
    mCiphersSecondaryMovers[ 5] = CipherType::kRippleMaskBlockCipher32;
    mCiphersSecondaryMovers[ 6] = CipherType::kRippleMaskBlockCipher32;

    // Slots 7-13: RippleMaskBlockCipher64 (7).
    mCiphersSecondaryMovers[ 7] = CipherType::kRippleMaskBlockCipher64;
    mCiphersSecondaryMovers[ 8] = CipherType::kRippleMaskBlockCipher64;
    mCiphersSecondaryMovers[ 9] = CipherType::kRippleMaskBlockCipher64;
    mCiphersSecondaryMovers[10] = CipherType::kRippleMaskBlockCipher64;
    mCiphersSecondaryMovers[11] = CipherType::kRippleMaskBlockCipher64;
    mCiphersSecondaryMovers[12] = CipherType::kRippleMaskBlockCipher64;
    mCiphersSecondaryMovers[13] = CipherType::kRippleMaskBlockCipher64;

    // Slots 14-20: ReverseMaskByteBlockCipher32 (7).
    mCiphersSecondaryMovers[14] = CipherType::kReverseMaskByteBlockCipher32;
    mCiphersSecondaryMovers[15] = CipherType::kReverseMaskByteBlockCipher32;
    mCiphersSecondaryMovers[16] = CipherType::kReverseMaskByteBlockCipher32;
    mCiphersSecondaryMovers[17] = CipherType::kReverseMaskByteBlockCipher32;
    mCiphersSecondaryMovers[18] = CipherType::kReverseMaskByteBlockCipher32;
    mCiphersSecondaryMovers[19] = CipherType::kReverseMaskByteBlockCipher32;
    mCiphersSecondaryMovers[20] = CipherType::kReverseMaskByteBlockCipher32;

    // Slots 21-27: ReverseMaskByteBlockCipher64 (7).
    mCiphersSecondaryMovers[21] = CipherType::kReverseMaskByteBlockCipher64;
    mCiphersSecondaryMovers[22] = CipherType::kReverseMaskByteBlockCipher64;
    mCiphersSecondaryMovers[23] = CipherType::kReverseMaskByteBlockCipher64;
    mCiphersSecondaryMovers[24] = CipherType::kReverseMaskByteBlockCipher64;
    mCiphersSecondaryMovers[25] = CipherType::kReverseMaskByteBlockCipher64;
    mCiphersSecondaryMovers[26] = CipherType::kReverseMaskByteBlockCipher64;
    mCiphersSecondaryMovers[27] = CipherType::kReverseMaskByteBlockCipher64;

    // Slots 28-31: InvertMaskCipher (4).
    mCiphersSecondaryMovers[28] = CipherType::kInvertMaskCipher;
    mCiphersSecondaryMovers[29] = CipherType::kInvertMaskCipher;
    mCiphersSecondaryMovers[30] = CipherType::kInvertMaskCipher;
    mCiphersSecondaryMovers[31] = CipherType::kInvertMaskCipher;
}

void Soccer2::InitializeExpanders() {
    mExpanders[ 0] = &mAldebaran; mExpanders[ 1] = &mAltair;   mExpanders[ 2] = &mAntares;  mExpanders[ 3] = &mArcturus;
    mExpanders[ 4] = &mBellatrix; mExpanders[ 5] = &mCapella;  mExpanders[ 6] = &mCastor;   mExpanders[ 7] = &mMimosa;
    mExpanders[ 8] = &mPolaris;   mExpanders[ 9] = &mPollux;   mExpanders[10] = &mProcyon;  mExpanders[11] = &mRegulus;
    mExpanders[12] = &mRigel;     mExpanders[13] = &mSaiph;    mExpanders[14] = &mSirius;   mExpanders[15] = &mVega;
}

void Soccer2::InitializeMaterials() {
    mMaterials[ 0] = mMaterialA; mMaterials[ 1] = mMaterialB; mMaterials[ 2] = mMaterialC; mMaterials[ 3] = mMaterialD;
    mMaterials[ 4] = mMaterialE; mMaterials[ 5] = mMaterialF; mMaterials[ 6] = mMaterialG; mMaterials[ 7] = mMaterialH;
    mMaterials[ 8] = mMaterialI; mMaterials[ 9] = mMaterialJ; mMaterials[10] = mMaterialK; mMaterials[11] = mMaterialL;
    mMaterials[12] = mMaterialM; mMaterials[13] = mMaterialN; mMaterials[14] = mMaterialO; mMaterials[15] = mMaterialP;
}

void Soccer2::InitializeWorkSpaces() {
    mWorkSpaces[ 0] = &mWorkSpaceA; mWorkSpaces[ 1] = &mWorkSpaceB; mWorkSpaces[ 2] = &mWorkSpaceC; mWorkSpaces[ 3] = &mWorkSpaceD;
    mWorkSpaces[ 4] = &mWorkSpaceE; mWorkSpaces[ 5] = &mWorkSpaceF; mWorkSpaces[ 6] = &mWorkSpaceG; mWorkSpaces[ 7] = &mWorkSpaceH;
    mWorkSpaces[ 8] = &mWorkSpaceI; mWorkSpaces[ 9] = &mWorkSpaceJ; mWorkSpaces[10] = &mWorkSpaceK; mWorkSpaces[11] = &mWorkSpaceL;
    mWorkSpaces[12] = &mWorkSpaceM; mWorkSpaces[13] = &mWorkSpaceN; mWorkSpaces[14] = &mWorkSpaceO; mWorkSpaces[15] = &mWorkSpaceP;
}

void Soccer2::UnrollNonceAndPasswordToScratch_Test(std::uint8_t *pPassword,
                                                   std::size_t pPasswordByteLength,
                                                   std::uint64_t pNonce) {
    std::uint8_t aNonceBytes[8];
    aNonceBytes[0] = static_cast<std::uint8_t>(pNonce >>  0); aNonceBytes[1] = static_cast<std::uint8_t>(pNonce >>  8);
    aNonceBytes[2] = static_cast<std::uint8_t>(pNonce >> 16); aNonceBytes[3] = static_cast<std::uint8_t>(pNonce >> 24);
    aNonceBytes[4] = static_cast<std::uint8_t>(pNonce >> 32); aNonceBytes[5] = static_cast<std::uint8_t>(pNonce >> 40);
    aNonceBytes[6] = static_cast<std::uint8_t>(pNonce >> 48); aNonceBytes[7] = static_cast<std::uint8_t>(pNonce >> 56);
    
    std::size_t aScratchIndex = 0;
    while (aScratchIndex < SOCCER_BLOCK_SIZE) {
        std::size_t aPasswordIndex = 0;
        while ((aPasswordIndex < pPasswordByteLength) && (aScratchIndex < SOCCER_BLOCK_SIZE)) {
            SOCCER_SCRATCH_WORKER_A[aScratchIndex] = pPassword[aPasswordIndex];
            aScratchIndex++;
            aPasswordIndex++;
        }
        std::size_t aNonceIndex = 0;
        while ((aNonceIndex < 8) && (aScratchIndex < SOCCER_BLOCK_SIZE)) {
            SOCCER_SCRATCH_WORKER_A[aScratchIndex] = aNonceBytes[aNonceIndex];
            aScratchIndex++;
            aNonceIndex++;
        }
    }
}

void Soccer2::UnrollNonceAndPasswordToScratch_Regular(std::uint8_t *pPassword,
                                                      std::size_t pPasswordByteLength,
                                                      std::uint64_t pNonce) {
    std::uint8_t aNonceBytes[8];
    aNonceBytes[0] = static_cast<std::uint8_t>(pNonce >>  0); aNonceBytes[1] = static_cast<std::uint8_t>(pNonce >>  8);
    aNonceBytes[2] = static_cast<std::uint8_t>(pNonce >> 16); aNonceBytes[3] = static_cast<std::uint8_t>(pNonce >> 24);
    aNonceBytes[4] = static_cast<std::uint8_t>(pNonce >> 32); aNonceBytes[5] = static_cast<std::uint8_t>(pNonce >> 40);
    aNonceBytes[6] = static_cast<std::uint8_t>(pNonce >> 48); aNonceBytes[7] = static_cast<std::uint8_t>(pNonce >> 56);
    
    std::size_t aScratchIndex = 0;
    while (aScratchIndex < S_BLOCK) {
        std::size_t aPasswordIndex = 0;
        while ((aPasswordIndex < pPasswordByteLength) && (aScratchIndex < S_BLOCK)) {
            SOCCER_SCRATCH_WORKER_A[aScratchIndex] = pPassword[aPasswordIndex];
            aScratchIndex++;
            aPasswordIndex++;
        }
        std::size_t aNonceIndex = 0;
        while ((aNonceIndex < 8) && (aScratchIndex < S_BLOCK)) {
            SOCCER_SCRATCH_WORKER_A[aScratchIndex] = aNonceBytes[aNonceIndex];
            aScratchIndex++;
            aNonceIndex++;
        }
    }
}

std::uint8_t *Soccer2::PopLaneS3() {
    if (mMaterialQuarter != 0U) {
        mMaterialIndex++;
        mMaterialQuarter = 0U;
    }
    if (mMaterialIndex >= 16U) {
        return nullptr;
    }

    std::uint8_t *aResult = mMaterials[mMaterialIndex];
    mMaterialIndex++;
    return aResult;
}

std::uint8_t *Soccer2::PopLaneS2() {
    if ((mMaterialQuarter + 2U) > 4U) {
        mMaterialIndex++;
        mMaterialQuarter = 0U;
    }
    if (mMaterialIndex >= 16U) {
        return nullptr;
    }

    std::uint8_t *aResult = mMaterials[mMaterialIndex] + (mMaterialQuarter * SOCCER_BLOCK_SIZE_L1);
    mMaterialQuarter += 2U;
    if (mMaterialQuarter == 4U) {
        mMaterialIndex++;
        mMaterialQuarter = 0U;
    }
    return aResult;
}

std::uint8_t *Soccer2::PopLaneS1() {
    if (mMaterialIndex >= 16U) {
        return nullptr;
    }
    
    std::uint8_t *aResult = mMaterials[mMaterialIndex] + (mMaterialQuarter * SOCCER_BLOCK_SIZE_L1);
    mMaterialQuarter++;
    if (mMaterialQuarter == 4U) {
        mMaterialIndex++;
        mMaterialQuarter = 0U;
    }
    return aResult;
}

std::uint8_t Soccer2::PopMask() {
    const std::uint8_t aResult = mMasks[mMaskCursor];
    mMaskCursor = ((mMaskCursor + 1) % SoccerMaskBank::mMaskGridWidth);
    return aResult;
}

std::int32_t Soccer2::GetByteRotationForStage(std::uint8_t pStage, std::size_t pRotationIndex) {
    if (pStage > kStageL1C || pRotationIndex >= kRotationsPerLayer) { return 0; }
    const auto aGroup = pRotationIndex * 3U + pStage / 3U;
    switch (pStage % 3U) {
        case 0U: return mRotationsByteL3[aGroup];
        case 1U: return mRotationsByteL2[aGroup];
        case 2U: return mRotationsByteL1[aGroup];
    }
    return 0;
}

const Soccer2::BitPlaneSamplingInput *Soccer2::GetBitPlaneInput(std::uint8_t pStage, CipherSamplingBank pBank) {
    if (pStage >= kSamplingStageCount || !IsBitPlaneSamplingBank(pBank)) { return nullptr; }
    const auto aIndex = static_cast<unsigned>(pBank) - static_cast<unsigned>(CipherSamplingBank::kBitPlaneFirstA);
    return &mBitPlaneInputs[pStage][aIndex / 3U][aIndex % 3U];
}

std::uint8_t Soccer2::GetBitPlaneMask(std::uint8_t pStage, CipherSamplingBank pBank) {
    if (IsBitPlaneRotationBank(pBank)) {
        const auto aRowIndex = static_cast<unsigned>(pBank) -
            static_cast<unsigned>(CipherSamplingBank::kBitPlaneRotationFirstRows);
        std::uint8_t aMask = 0U, aCoveredRows = 0U;
        for (std::size_t aGroup = 0U; aGroup < 3U; ++aGroup) {
            const auto aGroupBank = BitPlaneSamplingBank(0U, aGroup);
            const auto *aInput = GetBitPlaneInput(pStage, aGroupBank);
            const auto aGroupMask = GetBitPlaneMask(pStage, aGroupBank);
            if (aInput == nullptr || aGroupMask == 0U || (aCoveredRows & aGroupMask) != 0U) { return 0U; }
            aCoveredRows |= aGroupMask;
            aMask |= static_cast<std::uint8_t>(1U << aInput->mRows[aRowIndex]);
        }
        return aCoveredRows == 0xFFU ? aMask : 0U;
    }
    const auto *aInput = GetBitPlaneInput(pStage, pBank);
    if (aInput == nullptr || (aInput->mCount != 2U && aInput->mCount != 3U)) { return 0U; }
    std::uint8_t aMask = 0U;
    for (std::size_t i = 0U; i < aInput->mCount; ++i) {
        if (aInput->mRows[i] >= 8U || (aMask & (1U << aInput->mRows[i])) != 0U) { return 0U; }
        aMask |= static_cast<std::uint8_t>(1U << aInput->mRows[i]);
    }
    return aMask;
}

Cipher *Soccer2::GenerateCipher(CipherType pType, std::uint8_t pStage, CipherSamplingBank pSamplingBank,
                               std::size_t pRotationIndex) {
    if (pStage > kStageL1C || (IS_ROTATION_ANY(pType) && pRotationIndex >= kRotationsPerLayer)) {
        return nullptr;
    }

    auto PopLane = [pStage]() -> std::uint8_t * {
        if ((pStage == kStageL3A) ||
            (pStage == kStageL3B) ||
            (pStage == kStageL3C)) {
            return PopLaneS3();
        }
        if ((pStage == kStageL2A) ||
            (pStage == kStageL2B) ||
            (pStage == kStageL2C)) {
            return PopLaneS2();
        }
        return PopLaneS1();
    };

    switch (pType) {
        case CipherType::kGateCipher:
            return new GateCipher{};
        case CipherType::kBitRotationCipherA:
            return new BitRotationCipherA{};
        case CipherType::kBitRotationCipherB:
            return new BitRotationCipherB{};
        case CipherType::kBitRotationThreeCipher:
            return new BitRotationThreeCipher{};
        case CipherType::kPasswordXORCipher:
            return new PasswordXORCipher(PopLane());
        case CipherType::kPasswordAddCipher:
            return new PasswordAddCipher(PopLane());
        case CipherType::kPasswordSubtractCipher:
            return new PasswordSubtractCipher(PopLane());

        case CipherType::kPasswordJumpXORCipher: {
            std::uint8_t *aPassword = PopLane();
            std::uint8_t *aJumps = PopLane();
            return new PasswordJumpXORCipher(aPassword, aJumps);
        }
        case CipherType::kPasswordJumpAddCipher: {
            std::uint8_t *aPassword = PopLane();
            std::uint8_t *aJumps = PopLane();
            return new PasswordJumpAddCipher(aPassword, aJumps);
        }
        case CipherType::kPasswordJumpSubtractCipher: {
            std::uint8_t *aPassword = PopLane();
            std::uint8_t *aJumps = PopLane();
            return new PasswordJumpSubtractCipher(aPassword, aJumps);
        }

        case CipherType::kPepperNoiseXORCipher: {
            std::uint8_t *aMask = PopLane();
            std::uint8_t *aNoise = PopLane();
            return new PepperNoiseXORCipher(aMask, aNoise);
        }
        case CipherType::kPepperJumpNoiseXORCipher: {
            std::uint8_t *aMask = PopLane();
            std::uint8_t *aNoise = PopLane();
            std::uint8_t *aJumps = PopLane();
            return new PepperJumpNoiseXORCipher(aMask, aNoise, aJumps);
        }
        case CipherType::kPepperDualJumpNoiseXORCipher: {
            std::uint8_t *aMask = PopLane();
            std::uint8_t *aNoise = PopLane();
            std::uint8_t *aMaskJumps = PopLane();
            std::uint8_t *aNoiseJumps = PopLane();
            return new PepperDualJumpNoiseXORCipher(aMask, aNoise, aMaskJumps, aNoiseJumps);
        }
        case CipherType::kRotateMaskCipher: {
            const std::int32_t aRotation = GetByteRotationForStage(pStage, pRotationIndex);
            const bool aDerived = IsBitPlaneMaskBank(pSamplingBank);
            if (IsBitPlaneRotationBank(pSamplingBank) &&
                pSamplingBank != BitPlaneRotationBank(pRotationIndex)) { return nullptr; }
            if (!aDerived && pSamplingBank != CipherSamplingBank::kByCipherType) { return nullptr; }
            const std::uint8_t aMask = aDerived ? GetBitPlaneMask(pStage, pSamplingBank) : PopMask();
            if (aDerived && aMask == 0U) { return nullptr; }
            return new RotateMaskCipher(aMask, aRotation);
        }
        case CipherType::kReverseMaskCipher:
            return new ReverseMaskCipher(PopMask());
        case CipherType::kInvertMaskCipher:
            return new InvertMaskCipher(PopMask());
        case CipherType::kReverseMaskByteBlockCipher32:
            return new ReverseMaskByteBlockCipher32(PopMask());
        case CipherType::kReverseMaskByteBlockCipher64:
            return new ReverseMaskByteBlockCipher64(PopMask());
        case CipherType::kSplintMaskBlockCipher32:
            return new SplintMaskBlockCipher32(PopMask());
        case CipherType::kSplintMaskBlockCipher64:
            return new SplintMaskBlockCipher64(PopMask());
        case CipherType::kRippleMaskBlockCipher32:
            return new RippleMaskBlockCipher32(PopMask());
        case CipherType::kRippleMaskBlockCipher64:
            return new RippleMaskBlockCipher64(PopMask());
        case CipherType::kRotateCipher: {
            const std::int32_t aRotation = GetByteRotationForStage(pStage, pRotationIndex);
            return new RotateCipher(aRotation);
        }
        case CipherType::kFrogTwoCipherA:
        case CipherType::kFrogThreeCipherA:
        case CipherType::kFrogTwoCipherB:
        case CipherType::kFrogThreeCipherB:
        case CipherType::kToadTwoCipherA:
        case CipherType::kToadThreeCipherA:
        case CipherType::kNewtTwoCipherA:
        case CipherType::kNewtThreeCipherA: {
            const bool aFrogB = pType == CipherType::kFrogTwoCipherB || pType == CipherType::kFrogThreeCipherB;
            const bool aFrog = aFrogB || pType == CipherType::kFrogTwoCipherA || pType == CipherType::kFrogThreeCipherA;
            const bool aToad = pType == CipherType::kToadTwoCipherA || pType == CipherType::kToadThreeCipherA;
            const bool aTwo = pType == CipherType::kFrogTwoCipherA || pType == CipherType::kFrogTwoCipherB || pType == CipherType::kToadTwoCipherA ||
                              pType == CipherType::kNewtTwoCipherA;
            if (pSamplingBank == CipherSamplingBank::kByCipherType) {
                if (aFrog) { pSamplingBank = CipherSamplingBank::kPlanet; }
                else if (aToad) { pSamplingBank = CipherSamplingBank::kMoon; }
                else { pSamplingBank = CipherSamplingBank::kStar; }
            }
            const std::uint8_t *r = nullptr;
            const std::int32_t *o = nullptr;
            std::size_t aCount = 0U;
            if (IsBitPlaneSamplingBank(pSamplingBank)) {
                const auto *aInput = GetBitPlaneInput(pStage, pSamplingBank);
                if (aInput == nullptr || GetBitPlaneMask(pStage, pSamplingBank) == 0U) { return nullptr; }
                r = aInput->mRows; o = aInput->mRotations; aCount = aInput->mCount;
            } else {
                const SamplingInput *aInput = nullptr;
                switch (pSamplingBank) {
                    case CipherSamplingBank::kPlanet: aInput = &mPlanetInputs[pStage]; break;
                    case CipherSamplingBank::kMoon: aInput = &mMoonInputs[pStage]; break;
                    case CipherSamplingBank::kStar: aInput = &mStarInputs[pStage]; break;
                    default: return nullptr;
                }
                r = aInput->mRows; o = aInput->mRotations; aCount = aInput->mCount;
            }
            if (aCount != (aTwo ? 2U : 3U)) { return nullptr; }
            if (aFrog) {
                if (aFrogB) {
                    if (aTwo) { return new FrogTwoCipherB(r[0], o[0], r[1], o[1]); }
                    return new FrogThreeCipherB(r[0], o[0], r[1], o[1], r[2], o[2]);
                }
                if (aTwo) { return new FrogTwoCipherA(r[0], o[0], r[1], o[1]); }
                return new FrogThreeCipherA(r[0], o[0], r[1], o[1], r[2], o[2]);
            }
            if (aToad) {
                if (aTwo) { return new ToadTwoCipherA(r[0], o[0], r[1], o[1]); }
                return new ToadThreeCipherA(r[0], o[0], r[1], o[1], r[2], o[2]);
            }
            if (aTwo) { return new NewtTwoCipherA(r[0], o[0], r[1], o[1]); }
            return new NewtThreeCipherA(r[0], o[0], r[1], o[1], r[2], o[2]);
        }
        default:
            return nullptr;
    }
}

void Soccer2::Zero() {
    std::memset(mMaterialA, 0, sizeof(mMaterialA));
    std::memset(mMaterialB, 0, sizeof(mMaterialB));
    std::memset(mMaterialC, 0, sizeof(mMaterialC));
    std::memset(mMaterialD, 0, sizeof(mMaterialD));
    std::memset(mMaterialE, 0, sizeof(mMaterialE));
    std::memset(mMaterialF, 0, sizeof(mMaterialF));
    std::memset(mMaterialG, 0, sizeof(mMaterialG));
    std::memset(mMaterialH, 0, sizeof(mMaterialH));
    std::memset(mMaterialI, 0, sizeof(mMaterialI));
    std::memset(mMaterialJ, 0, sizeof(mMaterialJ));
    std::memset(mMaterialK, 0, sizeof(mMaterialK));
    std::memset(mMaterialL, 0, sizeof(mMaterialL));
    std::memset(mMaterialM, 0, sizeof(mMaterialM));
    std::memset(mMaterialN, 0, sizeof(mMaterialN));
    std::memset(mMaterialO, 0, sizeof(mMaterialO));
    std::memset(mMaterialP, 0, sizeof(mMaterialP));

    std::memset(mRandom, 0, sizeof(mRandom));
    std::memset(mCollapseLaneA, 0, sizeof(mCollapseLaneA));
    std::memset(mCollapseLaneB, 0, sizeof(mCollapseLaneB));
    std::memset(mCollapseLaneC, 0, sizeof(mCollapseLaneC));
    std::memset(mCollapseLaneD, 0, sizeof(mCollapseLaneD));
    std::memset(mCondenseLaneA, 0, sizeof(mCondenseLaneA));
    std::memset(mCondenseLaneB, 0, sizeof(mCondenseLaneB));
    std::memset(mCondenseLaneC, 0, sizeof(mCondenseLaneC));
    std::memset(mCondenseLaneD, 0, sizeof(mCondenseLaneD));
    std::memset(mIndexListA, 0, sizeof(mIndexListA));
    std::memset(mIndexListB, 0, sizeof(mIndexListB));
    std::memset(mPremiumSeed, 0, sizeof(mPremiumSeed));
    std::memset(mMasks, 0, sizeof(mMasks));
    mBitPlanes = {};
    for (auto &aStage : mBitPlaneInputs) {
        for (auto &aPass : aStage) { for (auto &aInput : aPass) { aInput = {}; } }
    }
    
    std::memset(mRotationsByteL3, 0, sizeof(mRotationsByteL3));
    std::memset(mRotationsByteL2, 0, sizeof(mRotationsByteL2));
    std::memset(mRotationsByteL1, 0, sizeof(mRotationsByteL1));
    for (const auto *aInputs : {mPlanetInputs, mMoonInputs, mStarInputs}) {
        for (std::size_t aStage = 0U; aStage < kSamplingStageCount; ++aStage) {
            std::fill_n(aInputs[aStage].mRows, aInputs[aStage].mCount, std::uint8_t{0U});
            std::fill_n(aInputs[aStage].mRotations, aInputs[aStage].mCount, std::int32_t{0});
        }
    }

    std::memset(mRotationWindowBase, 0, sizeof(mRotationWindowBase));
    std::memset(mRotationWindow, 0, sizeof(mRotationWindow));
    std::memset(mRotationWindowBlockList, 0, sizeof(mRotationWindowBlockList));
    std::memset(mRotationWindowListL1, 0, sizeof(mRotationWindowListL1));
    std::memset(mRotationWindowListL2, 0, sizeof(mRotationWindowListL2));
    std::memset(mRotationWindowListL3, 0, sizeof(mRotationWindowListL3));
    std::memset(mRotationWindowListFree, 0, sizeof(mRotationWindowListFree));
    mRotationWindowBlockListCount = mRotationWindowBaseReadCount = 0U;
    mPlanSelectionValue = 0ULL;

    mWorkSpaceA.Zero();
    mWorkSpaceB.Zero();
    mWorkSpaceC.Zero();
    mWorkSpaceD.Zero();
    mWorkSpaceE.Zero();
    mWorkSpaceF.Zero();
    mWorkSpaceG.Zero();
    mWorkSpaceH.Zero();
    mWorkSpaceI.Zero();
    mWorkSpaceJ.Zero();
    mWorkSpaceK.Zero();
    mWorkSpaceL.Zero();
    mWorkSpaceM.Zero();
    mWorkSpaceN.Zero();
    mWorkSpaceO.Zero();
    mWorkSpaceP.Zero();
    
    mStarter.Zero();
    
    mAldebaran.Zero();
    mAltair.Zero();
    mAntares.Zero();
    mArcturus.Zero();
    mBellatrix.Zero();
    mCapella.Zero();
    mCastor.Zero();
    mMimosa.Zero();
    mPolaris.Zero();
    mPollux.Zero();
    mProcyon.Zero();
    mRegulus.Zero();
    mRigel.Zero();
    mSaiph.Zero();
    mSirius.Zero();
    mVega.Zero();
    
    InitializeCiphers();

    for (std::size_t aIndex=0U; aIndex<SOCCER_EXPANDER_COUNT; aIndex++) {
        mExpanders[aIndex] = nullptr;
        mClaimed[aIndex] = false;
        mShuffleExpanders[aIndex] = nullptr;
    }

    for (std::size_t aIndex=0U; aIndex<16U; aIndex++) {
        mMaterials[aIndex] = nullptr;
        mWorkSpaces[aIndex] = nullptr;
        mSources[aIndex] = nullptr;

        mClaimedExpanders[aIndex] = nullptr;
        mClaimedMaterials[aIndex] = nullptr;
        mClaimedWorkSpaces[aIndex] = nullptr;

        mShuffleMaterials[aIndex] = nullptr;
        mShuffleWorkSpaces[aIndex] = nullptr;
    }

    for (std::size_t aCrossIndex=0U; aCrossIndex<4U; aCrossIndex++) {
        for (std::size_t aLaneIndex=0U; aLaneIndex<16U; aLaneIndex++) {
            mCross[aCrossIndex][aLaneIndex] = nullptr;
        }
    }

    for (std::size_t aLaneIndex=0U; aLaneIndex<16U; aLaneIndex++) {
        mCrossPoolCount[aLaneIndex] = 0U;
        for (std::size_t aPoolIndex=0U; aPoolIndex<64U; aPoolIndex++) {
            mCrossPool[aLaneIndex][aPoolIndex] = nullptr;
            mCrossPermutations[aLaneIndex][aPoolIndex] = 0U;
        }
    }

    mCryptex9.Zero();

    mCryptex9.Free();

    mClaimedExpanderCount = 0U;
    mClaimedMaterialCount = 0U;
    mClaimedWorkSpaceCount = 0U;

    mMaskCursor = 0U;
    mMaterialIndex = 0U;
    mMaterialQuarter = 0U;
    mTestBlockLength = 0U;

    mSeedProgressCompleted = 0U;
    mSeedProgressTotal = 0U;

    mStrength = EncryptionStrength::kNormal;
}

void Soccer2::Shuffle_CROWSCIMASSORMATEX() {
    constexpr std::size_t cSpan = 256U;
    constexpr std::size_t cBlockSpan = 4U * cSpan;
    static_assert(S_BLOCK == (32U * cBlockSpan));

    /*

     materials // block 0
     sources // block 1
     work_spaces // block 2
     expanders // block 3
     ciphers // block 4
     permute_0_3 // block 5
     permute_4_7 // block 6
     permute_8_11 // block 7
     permute_12_15 // block 8
     
     materials // block 9
     sources // block 10
     work_spaces // block 11
     expanders // block 12
     ciphers // block 13
     permute_0_3 // block 14
     permute_4_7 // block 15
     permute_8_11 // block 16
     permute_12_15 // block 17
     
     materials // block 18
     sources // block 19
     work_spaces // block 20
     expanders // block 21
     ciphers // block 22
     permute_0_3 // block 23
     permute_4_7 // block 24
     permute_8_11 // block 25
     permute_12_15 // block 26
     
     materials // block 27
     sources // block 28
     work_spaces // block 29
     expanders // block 30
     ciphers // block 31
    */
    
    // Materials: blocks 0, 9, 18, and 27.
    if (mStrength == EncryptionStrength::kWeak) {
        TwistShuffle::ShuffleList4(mMaterials, mRandom,  0U * cBlockSpan,  1U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList4(mMaterials, mRandom,  9U * cBlockSpan, 10U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList4(mMaterials, mRandom, 18U * cBlockSpan, 19U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList4(mMaterials, mRandom, 27U * cBlockSpan, 28U * cBlockSpan, 1U);
    } else if (mStrength == EncryptionStrength::kStrong) {
        TwistShuffle::ShuffleList16(mMaterials, mRandom,  0U * cBlockSpan,  1U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList16(mMaterials, mRandom,  9U * cBlockSpan, 10U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList16(mMaterials, mRandom, 18U * cBlockSpan, 19U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList16(mMaterials, mRandom, 27U * cBlockSpan, 28U * cBlockSpan, 1U);
    } else {
        TwistShuffle::ShuffleList8(mMaterials, mRandom,  0U * cBlockSpan,  1U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList8(mMaterials, mRandom,  9U * cBlockSpan, 10U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList8(mMaterials, mRandom, 18U * cBlockSpan, 19U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList8(mMaterials, mRandom, 27U * cBlockSpan, 28U * cBlockSpan, 1U);
    }

    // Expanders: blocks 3, 12, 21, and 30.
    TwistShuffle::ShuffleList16(mExpanders, mRandom,  3U * cBlockSpan,  4U * cBlockSpan, 1U);
    TwistShuffle::ShuffleList16(mExpanders, mRandom, 12U * cBlockSpan, 13U * cBlockSpan, 1U);
    TwistShuffle::ShuffleList16(mExpanders, mRandom, 21U * cBlockSpan, 22U * cBlockSpan, 1U);
    TwistShuffle::ShuffleList16(mExpanders, mRandom, 30U * cBlockSpan, 31U * cBlockSpan, 1U);

    // Work spaces: blocks 2, 11, 20, and 29.
    if (mStrength == EncryptionStrength::kWeak) {
        TwistShuffle::ShuffleList4(mWorkSpaces, mRandom,  2U * cBlockSpan,  3U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList4(mWorkSpaces, mRandom, 11U * cBlockSpan, 12U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList4(mWorkSpaces, mRandom, 20U * cBlockSpan, 21U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList4(mWorkSpaces, mRandom, 29U * cBlockSpan, 30U * cBlockSpan, 1U);
    } else if (mStrength == EncryptionStrength::kStrong) {
        TwistShuffle::ShuffleList16(mWorkSpaces, mRandom,  2U * cBlockSpan,  3U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList16(mWorkSpaces, mRandom, 11U * cBlockSpan, 12U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList16(mWorkSpaces, mRandom, 20U * cBlockSpan, 21U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList16(mWorkSpaces, mRandom, 29U * cBlockSpan, 30U * cBlockSpan, 1U);
    } else {
        TwistShuffle::ShuffleList8(mWorkSpaces, mRandom,  2U * cBlockSpan,  3U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList8(mWorkSpaces, mRandom, 11U * cBlockSpan, 12U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList8(mWorkSpaces, mRandom, 20U * cBlockSpan, 21U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList8(mWorkSpaces, mRandom, 29U * cBlockSpan, 30U * cBlockSpan, 1U);
    }

    // Ciphers: blocks 4, 13, 22, and 31. The first three 256-byte quarters
    // select mutate/primary/secondary pools; the former mix quarter is unused.
    constexpr std::size_t cCipherBlocks[] = {4U, 13U, 22U, 31U};
    for (const std::size_t aBlockIndex : cCipherBlocks) {
        const std::size_t aStart = aBlockIndex * cBlockSpan;
        TwistShuffle::ShuffleList32(mCiphersMutate,          mRandom, aStart,              aStart + 1U * cSpan, 1U);
        TwistShuffle::ShuffleList32(mCiphersPrimaryMovers,   mRandom, aStart + 1U * cSpan, aStart + 2U * cSpan, 1U);
        TwistShuffle::ShuffleList32(mCiphersSecondaryMovers, mRandom, aStart + 2U * cSpan, aStart + 3U * cSpan, 1U);
    }

    // Sources: blocks 1, 10, 19, and 28.
    if (mStrength == EncryptionStrength::kWeak) {
        TwistShuffle::ShuffleList4(mSources, mRandom,  1U * cBlockSpan,  2U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList4(mSources, mRandom, 10U * cBlockSpan, 11U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList4(mSources, mRandom, 19U * cBlockSpan, 20U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList4(mSources, mRandom, 28U * cBlockSpan, 29U * cBlockSpan, 1U);
    } else if (mStrength == EncryptionStrength::kStrong) {
        TwistShuffle::ShuffleList16(mSources, mRandom,  1U * cBlockSpan,  2U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList16(mSources, mRandom, 10U * cBlockSpan, 11U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList16(mSources, mRandom, 19U * cBlockSpan, 20U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList16(mSources, mRandom, 28U * cBlockSpan, 29U * cBlockSpan, 1U);
    } else {
        TwistShuffle::ShuffleList8(mSources, mRandom,  1U * cBlockSpan,  2U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList8(mSources, mRandom, 10U * cBlockSpan, 11U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList8(mSources, mRandom, 19U * cBlockSpan, 20U * cBlockSpan, 1U);
        TwistShuffle::ShuffleList8(mSources, mRandom, 28U * cBlockSpan, 29U * cBlockSpan, 1U);
    }
}

void Soccer2::Shuffle_CROPER(std::size_t pPermutationCount) {
    constexpr std::size_t cSpan = 256U;
    constexpr std::size_t cBlockSpan = 4U * cSpan;
    constexpr std::size_t cCrossBlocks[3][4] = {
        { 5U,  6U,  7U,  8U},
        {14U, 15U, 16U, 17U},
        {23U, 24U, 25U, 26U},
    };
    static_assert(S_BLOCK == (32U * cBlockSpan));
    
    for (std::size_t aRoundIndex=0U; aRoundIndex<3U; aRoundIndex++) {
        for (std::size_t aLaneGroup=0U; aLaneGroup<4U; aLaneGroup++) {
            const std::size_t aBlockIndex = cCrossBlocks[aRoundIndex][aLaneGroup];
            for (std::size_t aQuarterIndex=0U; aQuarterIndex<4U; aQuarterIndex++) {
                const std::size_t aLaneIndex = (aLaneGroup * 4U) + aQuarterIndex;
                const std::size_t aStartIndex = (aBlockIndex * cBlockSpan) + (aQuarterIndex * cSpan);
                const std::size_t aCeilingIndex = aStartIndex + cSpan;

                if (pPermutationCount == 4U) {
                    TwistShuffle::ShuffleList4(mCrossPermutations[aLaneIndex],
                                               mRandom,
                                               aStartIndex,
                                               aCeilingIndex,
                                               1U);
                } else if (pPermutationCount == 8U) {
                    TwistShuffle::ShuffleList8(mCrossPermutations[aLaneIndex],
                                               mRandom,
                                               aStartIndex,
                                               aCeilingIndex,
                                               1U);
                } else if (pPermutationCount == 16U) {
                    TwistShuffle::ShuffleList16(mCrossPermutations[aLaneIndex],
                                                mRandom,
                                                aStartIndex,
                                                aCeilingIndex,
                                                1U);
                } else if (pPermutationCount == 32U) {
                    TwistShuffle::ShuffleList32(mCrossPermutations[aLaneIndex],
                                                mRandom,
                                                aStartIndex,
                                                aCeilingIndex,
                                                1U);
                } else {
                    TwistShuffle::ShuffleList64(mCrossPermutations[aLaneIndex],
                                                mRandom,
                                                aStartIndex,
                                                aCeilingIndex,
                                                1U);
                }
            }
        }
    }
}

bool Soccer2::TwistRound(std::size_t pBlockIndex,
                         bool pIsWarmUpRound,
                         MUTABLE_PARAMS,
                         const std::atomic<bool> *pCancelled) {
    
    std::size_t aComplexity = COMPLEXITY_NORMAL;
    std::size_t aReverseCount = 2U;
    if (mStrength == EncryptionStrength::kWeak) {
        aComplexity = COMPLEXITY_WEAK;
        aReverseCount = 1U;
    } else if (mStrength == EncryptionStrength::kStrong) {
        aComplexity = COMPLEXITY_STRONG;
        aReverseCount = 4U;
    }
    
    static_assert(BLOCK_COUNT >= H_KEY);
    const bool aStifleKey =
        (!pIsWarmUpRound) && (pBlockIndex >= (BLOCK_COUNT - H_KEY));
    
    READ_IN_MUTABLE_PARAMS_INTERNAL;
    const std::size_t aDestinationByteIndex = pBlockIndex * S_BLOCK;
    for (std::size_t aLaneIndex=0U; aLaneIndex<aComplexity; aLaneIndex++) {
        mExpanders[aLaneIndex]->TwistBlock(mWorkSpaces[aLaneIndex],
                                           mSources[aLaneIndex],
                                           mCross[0][aLaneIndex],
                                           mCross[1][aLaneIndex],
                                           mCross[2][aLaneIndex],
                                           mCross[3][aLaneIndex],
                                           &mMaterials[aLaneIndex][aDestinationByteIndex],
                                           aStifleKey,
                                           ARX_STATE_VARS);
        
        if (pCancelled != nullptr) {
            if (pCancelled->load(std::memory_order_relaxed)) {
                return false;
            }
        }
        
        AdvanceSeedProgress(kExpanderTwistCost);
    }

    for (std::size_t aLaneIndex=0U; aLaneIndex<aComplexity; aLaneIndex++) {
        mSources[aLaneIndex] = &mMaterials[aLaneIndex][aDestinationByteIndex];
    }
    
    if (mStrength == EncryptionStrength::kWeak) {
        FoldMaterialsIntoRandomForBlock_4(pBlockIndex);
    } else if (mStrength == EncryptionStrength::kStrong) {
        FoldMaterialsIntoRandomForBlock_16(pBlockIndex);
    } else {
        FoldMaterialsIntoRandomForBlock_8(pBlockIndex);
    }
    
    for (std::size_t aMaterialIndex=0U; aMaterialIndex<aReverseCount; aMaterialIndex++) {
        std::reverse(mMaterials[aMaterialIndex] + aDestinationByteIndex,
                     mMaterials[aMaterialIndex] + aDestinationByteIndex + S_BLOCK);
    }
    
    Shuffle_CROWSCIMASSORMATEX();
    
    WRITE_OUT_MUTABLE_PARAMS;
    
    return true;
}

bool Soccer2::SeedPrologue_Regular_A(std::uint8_t *pPassword,
                                     std::size_t pPasswordByteLength,
                                     std::uint64_t pNonce,
                                     MUTABLE_PARAMS,
                                     const std::atomic<bool> *pCancelled) {
    
    std::size_t aPower = 0U;
    if (mStrength == EncryptionStrength::kWeak) {
        aPower = 1U;
    } else if (mStrength == EncryptionStrength::kStrong) {
        aPower = 4U;
    } else {
        aPower = 2U;
    }
    
    const std::size_t aWarmUpStartIndex = (BLOCK_COUNT - WARM_UP_BLOCKS) * S_BLOCK;
    
    READ_IN_MUTABLE_PARAMS_INTERNAL;
    
    for (std::size_t aSpanIndex=0U; aSpanIndex<4U; aSpanIndex++) {
        for (std::size_t aPowerIndex=0U; aPowerIndex<aPower; aPowerIndex++) {
            const std::size_t aClaimedIndex = mClaimedMaterialCount;

            mClaimedExpanders[aClaimedIndex] = mExpanders[aPowerIndex];
            mClaimedExpanderCount++;

            mClaimedMaterials[aClaimedIndex] = mMaterials[aPowerIndex];
            mClaimedMaterialCount++;

            mClaimedWorkSpaces[aClaimedIndex] = mWorkSpaces[aPowerIndex];
            mClaimedWorkSpaceCount++;

            mClaimedExpanders[aClaimedIndex]->Seed(mClaimedWorkSpaces[aClaimedIndex],
                                                   pNonce,
                                                   pPassword,
                                                   pPasswordByteLength,
                                                   &mClaimedMaterials[aClaimedIndex][aWarmUpStartIndex],
                                                   ARX_STATE_VARS);
            AdvanceSeedProgress(kExpanderSeedCost);
            
            if (pCancelled != nullptr) {
                if (pCancelled->load(std::memory_order_relaxed)) {
                    return false;
                }
            }
            
        }

        if (aSpanIndex < 3U) {
            Shuffle_MEWBlockZero(&mClaimedMaterials[mClaimedMaterialCount - 1U][aWarmUpStartIndex]);
        }
    }
    
    WRITE_OUT_MUTABLE_PARAMS;
    
    return true;
}

void Soccer2::SeedPrologue_Regular_B() {
    for (std::size_t aIndex=0U; aIndex<mClaimedMaterialCount; aIndex++) {
        mMaterials[aIndex] = mClaimedMaterials[aIndex];
    }

    std::size_t aMaterialWriteIndex = mClaimedMaterialCount;
    for (std::size_t aShuffledIndex=0U; aShuffledIndex<16U; aShuffledIndex++) {
        bool aIsClaimed = false;
        for (std::size_t aClaimedIndex=0U; aClaimedIndex<mClaimedMaterialCount; aClaimedIndex++) {
            if (mShuffleMaterials[aShuffledIndex] == mClaimedMaterials[aClaimedIndex]) {
                aIsClaimed = true;
                break;
            }
        }
        if (!aIsClaimed) {
            mMaterials[aMaterialWriteIndex] = mShuffleMaterials[aShuffledIndex];
            aMaterialWriteIndex++;
        }
    }

    for (std::size_t aIndex=0U; aIndex<mClaimedExpanderCount; aIndex++) {
        mExpanders[aIndex] = mClaimedExpanders[aIndex];
    }

    std::size_t aExpanderWriteIndex = mClaimedExpanderCount;
    for (std::size_t aShuffledIndex=0U; aShuffledIndex<SOCCER_EXPANDER_COUNT; aShuffledIndex++) {
        bool aIsClaimed = false;
        for (std::size_t aClaimedIndex=0U; aClaimedIndex<mClaimedExpanderCount; aClaimedIndex++) {
            if (mShuffleExpanders[aShuffledIndex] == mClaimedExpanders[aClaimedIndex]) {
                aIsClaimed = true;
                break;
            }
        }
        if (!aIsClaimed) {
            mExpanders[aExpanderWriteIndex] = mShuffleExpanders[aShuffledIndex];
            aExpanderWriteIndex++;
        }
    }

    for (std::size_t aIndex=0U; aIndex<mClaimedWorkSpaceCount; aIndex++) {
        mWorkSpaces[aIndex] = mClaimedWorkSpaces[aIndex];
    }

    std::size_t aWorkSpaceWriteIndex = mClaimedWorkSpaceCount;
    for (std::size_t aShuffledIndex=0U; aShuffledIndex<16U; aShuffledIndex++) {
        bool aIsClaimed = false;
        for (std::size_t aClaimedIndex=0U; aClaimedIndex<mClaimedWorkSpaceCount; aClaimedIndex++) {
            if (mShuffleWorkSpaces[aShuffledIndex] == mClaimedWorkSpaces[aClaimedIndex]) {
                aIsClaimed = true;
                break;
            }
        }
        if (!aIsClaimed) {
            mWorkSpaces[aWorkSpaceWriteIndex] = mShuffleWorkSpaces[aShuffledIndex];
            aWorkSpaceWriteIndex++;
        }
    }

    const std::size_t aFirstWarmUpBlockIndex = BLOCK_COUNT - WARM_UP_BLOCKS;
    const std::size_t aFirstWarmUpByteIndex = aFirstWarmUpBlockIndex * S_BLOCK;
    if (mStrength == EncryptionStrength::kWeak) {
        FoldMaterialsIntoRandomForBlock_4(aFirstWarmUpBlockIndex);
        
        for (std::size_t aIndex=0U; aIndex<COMPLEXITY_WEAK; aIndex++) {
            mSources[aIndex] = &mMaterials[aIndex][aFirstWarmUpByteIndex];
        }
        
    } else if (mStrength == EncryptionStrength::kStrong) {
        FoldMaterialsIntoRandomForBlock_16(aFirstWarmUpBlockIndex);
        
        for (std::size_t aIndex=0U; aIndex<COMPLEXITY_STRONG; aIndex++) {
            mSources[aIndex] = &mMaterials[aIndex][aFirstWarmUpByteIndex];
        }
    } else {
        FoldMaterialsIntoRandomForBlock_8(aFirstWarmUpBlockIndex);
        
        for (std::size_t aIndex=0U; aIndex<COMPLEXITY_NORMAL; aIndex++) {
            mSources[aIndex] = &mMaterials[aIndex][aFirstWarmUpByteIndex];
        }
    }
}

void Soccer2::ArrangeCrossPool(std::size_t pComplexity) {
    constexpr std::size_t aCrossCount = 4U;
    constexpr std::size_t aCrossPoolCapacity = 64U;

    for (std::size_t aLaneIndex=0U; aLaneIndex<pComplexity; aLaneIndex++) {
        const std::size_t aPoolCount = mCrossPoolCount[aLaneIndex];
        if ((aPoolCount < aCrossCount) || (aPoolCount > aCrossPoolCapacity)) {
            std::abort();
        }

        for (std::size_t aCrossIndex=0U; aCrossIndex<aCrossCount; aCrossIndex++) {
            const std::size_t aPoolIndex =
                mCrossPermutations[aLaneIndex][aCrossIndex];
            if (aPoolIndex >= aPoolCount) {
                std::abort();
            }
            mCross[aCrossIndex][aLaneIndex] = mCrossPool[aLaneIndex][aPoolIndex];
        }
    }
}

void Soccer2::InitializeCrossPermutations() {
    for (std::size_t aLaneIndex=0U; aLaneIndex<16U; aLaneIndex++) {
        for (std::size_t aPoolIndex=0U; aPoolIndex<64U; aPoolIndex++) {
            mCrossPermutations[aLaneIndex][aPoolIndex] = aPoolIndex;
        }
    }
}

void Soccer2::BuildCrossPool_WarmUp1(std::size_t pComplexity,
                                     std::size_t pCurrentByteIndex) {
    static_assert((COMPLEXITY_STRONG * 2U) == 32U);

    InitializeCrossPermutations();

    for (std::size_t aLaneIndex=0U; aLaneIndex<pComplexity; aLaneIndex++) {
        mCrossPoolCount[aLaneIndex] = 0U;
        for (std::size_t aPoolIndex=0U; aPoolIndex<64U; aPoolIndex++) {
            mCrossPool[aLaneIndex][aPoolIndex] = nullptr;
        }

        for (std::size_t aMaterialIndex=0U;
             aMaterialIndex<pComplexity;
             aMaterialIndex++) {
            std::uint8_t *aCandidate =
                &mMaterials[aMaterialIndex][pCurrentByteIndex];
            if (aCandidate != mSources[aLaneIndex]) {
                mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = aCandidate;
                mCrossPoolCount[aLaneIndex]++;
            }
        }

        mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = SOCCER_PRELUDE_RAND;
        mCrossPoolCount[aLaneIndex]++;
    }
}

void Soccer2::BuildCrossPool_WarmUp2(std::size_t pComplexity,
                                     std::size_t pPreviousByteIndex,
                                     std::size_t pCurrentByteIndex) {
    InitializeCrossPermutations();

    for (std::size_t aLaneIndex=0U; aLaneIndex<pComplexity; aLaneIndex++) {
        mCrossPoolCount[aLaneIndex] = 0U;
        for (std::size_t aPoolIndex=0U; aPoolIndex<64U; aPoolIndex++) {
            mCrossPool[aLaneIndex][aPoolIndex] = nullptr;
        }

        for (std::size_t aMaterialIndex=0U;
             aMaterialIndex<pComplexity;
             aMaterialIndex++) {
            mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] =
                &mMaterials[aMaterialIndex][pPreviousByteIndex];
            mCrossPoolCount[aLaneIndex]++;
        }

        for (std::size_t aMaterialIndex=0U;
             aMaterialIndex<pComplexity;
             aMaterialIndex++) {
            std::uint8_t *aCandidate =
                &mMaterials[aMaterialIndex][pCurrentByteIndex];
            if (aCandidate != mSources[aLaneIndex]) {
                mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = aCandidate;
                mCrossPoolCount[aLaneIndex]++;
            }
        }

        mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = SOCCER_PRELUDE_RAND;
        mCrossPoolCount[aLaneIndex]++;
    }
}

void Soccer2::BuildCrossPool_WarmUp4(std::size_t pComplexity,
                                     std::size_t pThreeRoundsBackByteIndex,
                                     std::size_t pTwoRoundsBackByteIndex,
                                     std::size_t pOneRoundBackByteIndex) {
    static_assert((COMPLEXITY_STRONG * 4U) == 64U);

    InitializeCrossPermutations();

    for (std::size_t aLaneIndex=0U; aLaneIndex<pComplexity; aLaneIndex++) {
        mCrossPoolCount[aLaneIndex] = 0U;
        for (std::size_t aPoolIndex=0U; aPoolIndex<64U; aPoolIndex++) {
            mCrossPool[aLaneIndex][aPoolIndex] = nullptr;
        }

        for (std::size_t aMaterialIndex=0U;
             aMaterialIndex<pComplexity;
             aMaterialIndex++) {
            if (mSources[aMaterialIndex] != mSources[aLaneIndex]) {
                mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] =
                    mSources[aMaterialIndex];
                mCrossPoolCount[aLaneIndex]++;
            }
        }

        mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = SOCCER_PRELUDE_RAND;
        mCrossPoolCount[aLaneIndex]++;

        for (std::size_t aMaterialIndex=0U; aMaterialIndex<pComplexity; aMaterialIndex++) {
            mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = &mMaterials[aMaterialIndex][pThreeRoundsBackByteIndex];
            mCrossPoolCount[aLaneIndex]++;
        }

        for (std::size_t aMaterialIndex=0U; aMaterialIndex<pComplexity; aMaterialIndex++) {
            mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = &mMaterials[aMaterialIndex][pTwoRoundsBackByteIndex];
            mCrossPoolCount[aLaneIndex]++;
        }

        for (std::size_t aMaterialIndex=0U; aMaterialIndex<pComplexity; aMaterialIndex++) {
            mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = &mMaterials[aMaterialIndex][pOneRoundBackByteIndex];
            mCrossPoolCount[aLaneIndex]++;
        }
    }
}

void Soccer2::BuildCrossPool_Regular(std::size_t pComplexity,
                                     std::size_t pFourRoundsBackByteIndex,
                                     std::size_t pThreeRoundsBackByteIndex,
                                     std::size_t pTwoRoundsBackByteIndex,
                                     std::size_t pOneRoundBackByteIndex) {
    static_assert((COMPLEXITY_STRONG * 4U) == 64U);

    InitializeCrossPermutations();

    for (std::size_t aLaneIndex=0U; aLaneIndex<pComplexity; aLaneIndex++) {
        mCrossPoolCount[aLaneIndex] = 0U;
        for (std::size_t aPoolIndex=0U; aPoolIndex<64U; aPoolIndex++) {
            mCrossPool[aLaneIndex][aPoolIndex] = nullptr;
        }
        
        for (std::size_t aMaterialIndex=0U; aMaterialIndex<pComplexity; aMaterialIndex++) {
            if (mSources[aMaterialIndex] != mSources[aLaneIndex]) {
                mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] =
                    mSources[aMaterialIndex];
                mCrossPoolCount[aLaneIndex]++;
            }
        }

        mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = &mMaterials[aLaneIndex][pFourRoundsBackByteIndex];
        mCrossPoolCount[aLaneIndex]++;

        for (std::size_t aMaterialIndex=0U; aMaterialIndex<pComplexity; aMaterialIndex++) {
            mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = &mMaterials[aMaterialIndex][pThreeRoundsBackByteIndex];
            mCrossPoolCount[aLaneIndex]++;
        }

        for (std::size_t aMaterialIndex=0U; aMaterialIndex<pComplexity; aMaterialIndex++) {
            mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = &mMaterials[aMaterialIndex][pTwoRoundsBackByteIndex];
            mCrossPoolCount[aLaneIndex]++;
        }

        for (std::size_t aMaterialIndex=0U; aMaterialIndex<pComplexity; aMaterialIndex++) {
            mCrossPool[aLaneIndex][mCrossPoolCount[aLaneIndex]] = &mMaterials[aMaterialIndex][pOneRoundBackByteIndex];
            mCrossPoolCount[aLaneIndex]++;
        }
    }
}

bool Soccer2::SeedPrologue_Regular_C(std::uint32_t *pAckWord,
                                     bool pForwardDeploy,
                                     MUTABLE_PARAMS,
                                     const std::atomic<bool> *pCancelled) {
    
    std::size_t aComplexity = COMPLEXITY_NORMAL;
    if (mStrength == EncryptionStrength::kWeak) {
        aComplexity = COMPLEXITY_WEAK;
    } else if (mStrength == EncryptionStrength::kStrong) {
        aComplexity = COMPLEXITY_STRONG;
    }

    static_assert(WARM_UP_ROUNDS == 5U);
    static_assert(WARM_UP_BLOCKS == 6U);
    const std::size_t aWarmUpSeedBlockIndex = BLOCK_COUNT - WARM_UP_BLOCKS;
    const std::size_t aWarmUpSeedByteIndex = aWarmUpSeedBlockIndex * S_BLOCK;
    const std::size_t aWarmUp1ByteIndex = (aWarmUpSeedBlockIndex + 1U) * S_BLOCK;
    const std::size_t aWarmUp2ByteIndex = (aWarmUpSeedBlockIndex + 2U) * S_BLOCK;
    const std::size_t aWarmUp3ByteIndex = (aWarmUpSeedBlockIndex + 3U) * S_BLOCK;
    
    READ_IN_MUTABLE_PARAMS_INTERNAL;

    Shuffle_CROWSCIMASSORMATEX();

    BuildCrossPool_WarmUp1(aComplexity, aWarmUpSeedByteIndex);
    Shuffle_CROPER(mCrossPoolCount[0]);
    ArrangeCrossPool(aComplexity);
    if (!TwistRound(aWarmUpSeedBlockIndex + 1U, true, ARX_STATE_VARS, pCancelled)) {
        return false;
    }

    BuildCrossPool_WarmUp2(aComplexity,
                           aWarmUpSeedByteIndex,
                           aWarmUp1ByteIndex);
    Shuffle_CROPER(mCrossPoolCount[0]);
    ArrangeCrossPool(aComplexity);
    if (!TwistRound(aWarmUpSeedBlockIndex + 2U, true, ARX_STATE_VARS, pCancelled)) {
        return false;
    }

    BuildCrossPool_WarmUp2(aComplexity,
                           aWarmUp1ByteIndex,
                           aWarmUp2ByteIndex);
    Shuffle_CROPER(mCrossPoolCount[0]);
    ArrangeCrossPool(aComplexity);
    if (!TwistRound(aWarmUpSeedBlockIndex + 3U, true, ARX_STATE_VARS, pCancelled)) {
        return false;
    }

    BuildCrossPool_WarmUp4(aComplexity,
                           aWarmUpSeedByteIndex,
                           aWarmUp1ByteIndex,
                           aWarmUp2ByteIndex);
    Shuffle_CROPER(mCrossPoolCount[0]);
    ArrangeCrossPool(aComplexity);
    if (!TwistRound(aWarmUpSeedBlockIndex + 4U, true, ARX_STATE_VARS, pCancelled)) {
        return false;
    }

    BuildCrossPool_Regular(aComplexity,
                           aWarmUpSeedByteIndex,
                           aWarmUp1ByteIndex,
                           aWarmUp2ByteIndex,
                           aWarmUp3ByteIndex);
    Shuffle_CROPER(mCrossPoolCount[0]);
    ArrangeCrossPool(aComplexity);
    if (!TwistRound(aWarmUpSeedBlockIndex + 5U, true, ARX_STATE_VARS, pCancelled)) {
        return false;
    }
    
    WRITE_OUT_MUTABLE_PARAMS;

    const std::size_t aAckByteIndex = SOCCER_BLOCK_SIZE - 1U;
    std::uint32_t aGeneratedAckWord = 0U;
    if (mStrength == EncryptionStrength::kWeak) {
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[0][aAckByteIndex]) <<  0U;
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[1][aAckByteIndex]) <<  8U;
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[2][aAckByteIndex]) << 16U;
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[3][aAckByteIndex]) << 24U;
    } else if (mStrength == EncryptionStrength::kStrong) {
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[ 3][aAckByteIndex]) <<  0U;
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[ 7][aAckByteIndex]) <<  8U;
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[11][aAckByteIndex]) << 16U;
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[15][aAckByteIndex]) << 24U;
    } else {
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[1][aAckByteIndex]) <<  0U;
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[3][aAckByteIndex]) <<  8U;
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[5][aAckByteIndex]) << 16U;
        aGeneratedAckWord |= static_cast<std::uint32_t>(mMaterials[7][aAckByteIndex]) << 24U;
    }

    if (pForwardDeploy) {
        *pAckWord = aGeneratedAckWord;
        return true;
    }

    return aGeneratedAckWord == *pAckWord;
}

bool Soccer2::SeedPrologue_Regular_D(MUTABLE_PARAMS,
                                     const std::atomic<bool> *pCancelled) {
    std::size_t aComplexity = COMPLEXITY_NORMAL;
    if (mStrength == EncryptionStrength::kWeak) {
        aComplexity = COMPLEXITY_WEAK;
    } else if (mStrength == EncryptionStrength::kStrong) {
        aComplexity = COMPLEXITY_STRONG;
    }
    
    READ_IN_MUTABLE_PARAMS_INTERNAL;

    for (std::size_t aRoundIndex=0U; aRoundIndex<BLOCK_COUNT; aRoundIndex++) {
        const std::size_t aFourRoundsBackBlockIndex = (aRoundIndex + BLOCK_COUNT - 5U) % BLOCK_COUNT;
        const std::size_t aThreeRoundsBackBlockIndex = (aRoundIndex + BLOCK_COUNT - 4U) % BLOCK_COUNT;
        const std::size_t aTwoRoundsBackBlockIndex = (aRoundIndex + BLOCK_COUNT - 3U) % BLOCK_COUNT;
        const std::size_t aOneRoundBackBlockIndex = (aRoundIndex + BLOCK_COUNT - 2U) % BLOCK_COUNT;
        BuildCrossPool_Regular(aComplexity,
                               aFourRoundsBackBlockIndex * S_BLOCK,
                               aThreeRoundsBackBlockIndex * S_BLOCK,
                               aTwoRoundsBackBlockIndex * S_BLOCK,
                               aOneRoundBackBlockIndex * S_BLOCK);
        Shuffle_CROPER(mCrossPoolCount[0]);
        ArrangeCrossPool(aComplexity);
        if (!TwistRound(aRoundIndex, false, ARX_STATE_VARS, pCancelled)) {
            return false;
        }
    }
    
    WRITE_OUT_MUTABLE_PARAMS;
    
    return true;
}

void Soccer2::FoldMaterialsIntoRandomForBlock_4(std::size_t pBlockIndex) {
    const std::size_t aStartIndex = pBlockIndex * S_BLOCK;
    for (std::size_t aByteIndex=0U; aByteIndex<S_BLOCK; aByteIndex++) {
        const std::size_t aMaterialIndex = aStartIndex + aByteIndex;
        const std::uint32_t aRandomIngress =
            (static_cast<std::uint32_t>(mMaterials[0][aMaterialIndex]) <<  0U) |
            (static_cast<std::uint32_t>(mMaterials[1][aMaterialIndex]) <<  8U) |
            (static_cast<std::uint32_t>(mMaterials[2][aMaterialIndex]) << 16U) |
            (static_cast<std::uint32_t>(mMaterials[3][aMaterialIndex]) << 24U);

        mRandom[aByteIndex] = static_cast<std::uint8_t>(TwistMix32::DiffuseA(aRandomIngress));
    }
}

void Soccer2::FoldMaterialsIntoRandomForBlock_8(std::size_t pBlockIndex) {
    const std::size_t aStartIndex = pBlockIndex * S_BLOCK;
    for (std::size_t aByteIndex=0U; aByteIndex<S_BLOCK; aByteIndex++) {
        const std::size_t aMaterialIndex = aStartIndex + aByteIndex;
        const std::uint64_t aRandomIngress =
            (static_cast<std::uint64_t>(mMaterials[0][aMaterialIndex]) <<  0U) |
            (static_cast<std::uint64_t>(mMaterials[1][aMaterialIndex]) <<  8U) |
            (static_cast<std::uint64_t>(mMaterials[2][aMaterialIndex]) << 16U) |
            (static_cast<std::uint64_t>(mMaterials[3][aMaterialIndex]) << 24U) |
            (static_cast<std::uint64_t>(mMaterials[4][aMaterialIndex]) << 32U) |
            (static_cast<std::uint64_t>(mMaterials[5][aMaterialIndex]) << 40U) |
            (static_cast<std::uint64_t>(mMaterials[6][aMaterialIndex]) << 48U) |
            (static_cast<std::uint64_t>(mMaterials[7][aMaterialIndex]) << 56U);

        mRandom[aByteIndex] = static_cast<std::uint8_t>(TwistMix64::DiffuseA(aRandomIngress));
    }
}

void Soccer2::FoldMaterialsIntoRandomForBlock_16(std::size_t pBlockIndex) {
    const std::size_t aStartIndex = pBlockIndex * S_BLOCK;
    for (std::size_t aByteIndex=0U; aByteIndex<S_BLOCK; aByteIndex++) {
        const std::size_t aMaterialIndex = aStartIndex + aByteIndex;

        const std::uint32_t aCrushIngressA =
            (static_cast<std::uint32_t>(mMaterials[ 0][aMaterialIndex]) <<  0U) |
            (static_cast<std::uint32_t>(mMaterials[ 1][aMaterialIndex]) <<  8U) |
            (static_cast<std::uint32_t>(mMaterials[ 2][aMaterialIndex]) << 16U) |
            (static_cast<std::uint32_t>(mMaterials[ 3][aMaterialIndex]) << 24U);
        const std::uint8_t aCrushA = static_cast<std::uint8_t>(TwistMix32::DiffuseA(aCrushIngressA));

        const std::uint32_t aCrushIngressB =
            (static_cast<std::uint32_t>(mMaterials[ 4][aMaterialIndex]) <<  0U) |
            (static_cast<std::uint32_t>(mMaterials[ 5][aMaterialIndex]) <<  8U) |
            (static_cast<std::uint32_t>(mMaterials[ 6][aMaterialIndex]) << 16U) |
            (static_cast<std::uint32_t>(mMaterials[ 7][aMaterialIndex]) << 24U);
        const std::uint8_t aCrushB = static_cast<std::uint8_t>(TwistMix32::DiffuseA(aCrushIngressB));

        const std::uint32_t aCrushIngressC =
            (static_cast<std::uint32_t>(mMaterials[ 8][aMaterialIndex]) <<  0U) |
            (static_cast<std::uint32_t>(mMaterials[ 9][aMaterialIndex]) <<  8U) |
            (static_cast<std::uint32_t>(mMaterials[10][aMaterialIndex]) << 16U) |
            (static_cast<std::uint32_t>(mMaterials[11][aMaterialIndex]) << 24U);
        const std::uint8_t aCrushC = static_cast<std::uint8_t>(TwistMix32::DiffuseA(aCrushIngressC));

        const std::uint32_t aCrushIngressD =
            (static_cast<std::uint32_t>(mMaterials[12][aMaterialIndex]) <<  0U) |
            (static_cast<std::uint32_t>(mMaterials[13][aMaterialIndex]) <<  8U) |
            (static_cast<std::uint32_t>(mMaterials[14][aMaterialIndex]) << 16U) |
            (static_cast<std::uint32_t>(mMaterials[15][aMaterialIndex]) << 24U);
        const std::uint8_t aCrushD = static_cast<std::uint8_t>(TwistMix32::DiffuseA(aCrushIngressD));

        const std::uint32_t aRandomIngress =
            (static_cast<std::uint32_t>(aCrushA) <<  0U) |
            (static_cast<std::uint32_t>(aCrushB) <<  8U) |
            (static_cast<std::uint32_t>(aCrushC) << 16U) |
            (static_cast<std::uint32_t>(aCrushD) << 24U);

        mRandom[aByteIndex] = static_cast<std::uint8_t>(TwistMix32::DiffuseA(aRandomIngress));
    }
}

bool Soccer2::AttemptSeed_Encrypt(EncryptionStrength pStrength,
                                  std::uint8_t *pPassword,
                                  std::size_t pPasswordByteLength,
                                  std::uint64_t pNonce,
                                  std::uint32_t *pAckWord,
                                  std::uint64_t pVersion,
                                  const std::atomic<bool> *pCancelled) {

    BeginSeedProgress(pStrength);
    
    if ((pPassword == nullptr) || (pPasswordByteLength == 0U) || (pAckWord == nullptr)) {
        return FinishSeedProgress(false);
    }

    std::uint32_t aAckWord = 0U;
    mStrength = pStrength;
    mCryptex9.Free();
    
    if (pStrength == EncryptionStrength::kTest) {
        if (!SeedPrelude_Test(pPassword, pPasswordByteLength, pNonce)) {
            return FinishSeedProgress(false);
        }
        aAckWord |= static_cast<std::uint32_t>(mMaterialA[S_BLOCK * 1]) <<  0U;
        aAckWord |= static_cast<std::uint32_t>(mMaterialA[S_BLOCK * 2]) <<  8U;
        aAckWord |= static_cast<std::uint32_t>(mMaterialA[S_BLOCK * 3]) << 16U;
        aAckWord |= static_cast<std::uint32_t>(mMaterialA[S_BLOCK * 4]) << 24U;
        *pAckWord = aAckWord;
        
        if (pCancelled != nullptr) {
            if (pCancelled->load(std::memory_order_relaxed)) {
                return FinishSeedProgress(false);
            } else {
                return FinishSeedProgress(true);
            }
        } else {
            return FinishSeedProgress(true);
        }
    }
    
    std::uint64_t aIngress = 0xE025CAEA83AB99CFULL;
    std::uint64_t aCarry = 0x6530BC4A53A443B8ULL;
    std::uint64_t aWandererA = 0x4E06885276D20E3DULL;
    std::uint64_t aWandererB = 0xEBF1E1AB6DF26920ULL;
    std::uint64_t aWandererC = 0x99478E05E833FBB1ULL;
    std::uint64_t aWandererD = 0x73A9F7B5B01778B2ULL;
    std::uint64_t aWandererE = 0xB9AB363EA936D1EDULL;
    std::uint64_t aWandererF = 0x847430D62AD62F79ULL;
    std::uint64_t aWandererG = 0x0D6FE89E3169B0E1ULL;
    std::uint64_t aWandererH = 0xD22934C37E3EE9B7ULL;
    std::uint64_t aWandererI = 0x648E293C4DCD6ED1ULL;
    std::uint64_t aWandererJ = 0xA31C40A884CAD927ULL;
    std::uint64_t aWandererK = 0x183169CC43C8BCE3ULL;
    
    // Chapter I - Prelude
    SeedPrelude_Regular_A(pPassword, pPasswordByteLength, pNonce);
    SeedPrelude_Regular_B(pNonce, ARX_STATE_VARS);
    SeedPrelude_Regular_C();
    
    if (pCancelled != nullptr) {
        if (pCancelled->load(std::memory_order_relaxed)) {
            return FinishSeedProgress(false);
        }
    }
    
    // Chapter II - Prologue
    if (!SeedPrologue_Regular_A(pPassword, pPasswordByteLength, pNonce, ARX_STATE_VARS, pCancelled)) {
        return FinishSeedProgress(false);
    }
    SeedPrologue_Regular_B();
    if (!SeedPrologue_Regular_C(pAckWord, true, ARX_STATE_VARS, pCancelled)) {
        return FinishSeedProgress(false);
    }
    if (!SeedPrologue_Regular_D(ARX_STATE_VARS, pCancelled)) {
        return FinishSeedProgress(false);
    }
    
    // Chapter III - Epilogue
    SeedEpilogue_Regular_A();
    SeedEpilogue_Regular_B();
    SeedEpilogue_Regular_C();
    if (!SeedEpilogue_Regular_D()) {
        return FinishSeedProgress(false);
    }
    
    if (pCancelled != nullptr) {
        if (pCancelled->load(std::memory_order_relaxed)) {
            return FinishSeedProgress(false);
        } else {
            return FinishSeedProgress(true);
        }
    } else {
        return FinishSeedProgress(true);
    }
}

bool Soccer2::AttemptSeed_Decrypt(EncryptionStrength pStrength,
                                  std::uint8_t *pPassword,
                                  std::size_t pPasswordByteLength,
                                  std::uint64_t pNonce,
                                  std::uint32_t pAckWord,
                                  std::uint64_t pVersion,
                                  const std::atomic<bool> *pCancelled) {

    BeginSeedProgress(pStrength);
    
    if ((pPassword == nullptr) || (pPasswordByteLength == 0U)) {
        return FinishSeedProgress(false);
    }

    mStrength = pStrength;
    mCryptex9.Free();
    
    if (pStrength == EncryptionStrength::kTest) {
        if (!SeedPrelude_Test(pPassword, pPasswordByteLength, pNonce)) {
            return FinishSeedProgress(false);
        }
        if (mMaterialA[S_BLOCK * 1] != static_cast<std::uint8_t>(((pAckWord >>  0) & 0xFFU))) { return FinishSeedProgress(false); }
        if (mMaterialA[S_BLOCK * 2] != static_cast<std::uint8_t>(((pAckWord >>  8) & 0xFFU))) { return FinishSeedProgress(false); }
        if (mMaterialA[S_BLOCK * 3] != static_cast<std::uint8_t>(((pAckWord >> 16) & 0xFFU))) { return FinishSeedProgress(false); }
        if (mMaterialA[S_BLOCK * 4] != static_cast<std::uint8_t>(((pAckWord >> 24) & 0xFFU))) { return FinishSeedProgress(false); }
        
        if (pCancelled != nullptr) {
            if (pCancelled->load(std::memory_order_relaxed)) {
                return FinishSeedProgress(false);
            } else {
                return FinishSeedProgress(true);
            }
        } else {
            return FinishSeedProgress(true);
        }
    }
    
    std::uint64_t aIngress = 0xE025CAEA83AB99CFULL;
    std::uint64_t aCarry = 0x6530BC4A53A443B8ULL;
    std::uint64_t aWandererA = 0x4E06885276D20E3DULL;
    std::uint64_t aWandererB = 0xEBF1E1AB6DF26920ULL;
    std::uint64_t aWandererC = 0x99478E05E833FBB1ULL;
    std::uint64_t aWandererD = 0x73A9F7B5B01778B2ULL;
    std::uint64_t aWandererE = 0xB9AB363EA936D1EDULL;
    std::uint64_t aWandererF = 0x847430D62AD62F79ULL;
    std::uint64_t aWandererG = 0x0D6FE89E3169B0E1ULL;
    std::uint64_t aWandererH = 0xD22934C37E3EE9B7ULL;
    std::uint64_t aWandererI = 0x648E293C4DCD6ED1ULL;
    std::uint64_t aWandererJ = 0xA31C40A884CAD927ULL;
    std::uint64_t aWandererK = 0x183169CC43C8BCE3ULL;
    
    // Chapter I - Prelude
    SeedPrelude_Regular_A(pPassword, pPasswordByteLength, pNonce);
    SeedPrelude_Regular_B(pNonce, ARX_STATE_VARS);
    SeedPrelude_Regular_C();
    
    if (pCancelled != nullptr) {
        if (pCancelled->load(std::memory_order_relaxed)) {
            FinishSeedProgress(false);
            return false;
        }
    }
    
    // Chapter II - Prologue
    std::uint32_t aAckWord = pAckWord;
    if (!SeedPrologue_Regular_A(pPassword, pPasswordByteLength, pNonce, ARX_STATE_VARS, pCancelled)) {
        return FinishSeedProgress(false);
    }
    SeedPrologue_Regular_B();
    if (!SeedPrologue_Regular_C(&aAckWord, false, ARX_STATE_VARS, pCancelled)) {
        return FinishSeedProgress(false);
    }
    if (!SeedPrologue_Regular_D(ARX_STATE_VARS, pCancelled)) {
        return FinishSeedProgress(false);
    }
    
    // Chapter III - Epilogue
    SeedEpilogue_Regular_A();
    SeedEpilogue_Regular_B();
    SeedEpilogue_Regular_C();
    if (!SeedEpilogue_Regular_D()) {
        return FinishSeedProgress(false);
    }
    
    if (pCancelled != nullptr) {
        if (pCancelled->load(std::memory_order_relaxed)) {
            return FinishSeedProgress(false);
        } else {
            return FinishSeedProgress(true);
        }
    } else {
        return FinishSeedProgress(true);
    }
}

void Soccer2::SetDelegate(SoccerDelegate *pDelegate) {
    mDelegate = pDelegate;
}

void Soccer2::BeginSeedProgress(EncryptionStrength pStrength) {
    mSeedProgressCompleted = 0U;
    mSeedProgressTotal = 0U;

    if (pStrength != EncryptionStrength::kTest) {
        std::size_t aComplexity = COMPLEXITY_NORMAL;
        if (pStrength == EncryptionStrength::kWeak) {
            aComplexity = COMPLEXITY_WEAK;
        } else if (pStrength == EncryptionStrength::kStrong) {
            aComplexity = COMPLEXITY_STRONG;
        }

        // One starter seed, one seed per active lane, then every warm-up and
        // main TwistBlock. Reserve the final unit for epilogue A through D.
        const std::size_t aSeedCount = 1U + aComplexity;
        const std::size_t aTwistCount = aComplexity * (WARM_UP_ROUNDS + BLOCK_COUNT);
        mSeedProgressTotal = (aSeedCount * kExpanderSeedCost) +
                             (aTwistCount * kExpanderTwistCost) +
                             kSeedEpilogueCost;
    }

    if (mDelegate != nullptr) {
        mDelegate->SeedProgress(0.0);
    }
}

void Soccer2::AdvanceSeedProgress(std::size_t pCost) {
    // These stages can also be called directly, outside an AttemptSeed call.
    if (mSeedProgressTotal == 0U) {
        return;
    }

    mSeedProgressCompleted += pCost;
    if (mDelegate != nullptr) {
        const double aPercent = 100.0 * static_cast<double>(mSeedProgressCompleted) /
                                static_cast<double>(mSeedProgressTotal);
        mDelegate->SeedProgress(aPercent);
    }
}

bool Soccer2::FinishSeedProgress(bool pSuccess) {
    mSeedProgressCompleted = 0U;
    mSeedProgressTotal = 0U;

    if (mDelegate != nullptr) {
        mDelegate->SeedProgress(100.0);
    }
    return pSuccess;
}

void Soccer2::ConfigureTestBuffers(std::uint32_t pTestBlockLength) {
    mTestBlockLength = pTestBlockLength;
}

bool Soccer2::EncryptBlock(std::uint8_t *pSource,
                           std::uint8_t *pDestination) {
    if ((pSource == nullptr) || (pDestination == nullptr)) {
        return false;
    }
    
    if (mStrength == EncryptionStrength::kTest) {
        for (std::size_t aIndex=0; aIndex<mTestBlockLength; aIndex++) {
            pDestination[aIndex] = pSource[aIndex] ^ mMaterialA[aIndex];
        }
        return true;
    }

    return mCryptex9.SealData(pSource,
                               SOCCER_SCRATCH_WORKER_A,
                               SOCCER_WORKER_B,
                               pDestination,
                               SOCCER_BLOCK_SIZE,
                               nullptr);
}

bool Soccer2::DecryptBlock(std::uint8_t *pSource,
                           std::uint8_t *pDestination) {
    if ((pSource == nullptr) || (pDestination == nullptr)) {
        return false;
    }

    if (mStrength == EncryptionStrength::kTest) {
        for (std::size_t aIndex=0; aIndex<mTestBlockLength; aIndex++) {
            pDestination[aIndex] = pSource[aIndex] ^ mMaterialA[aIndex];
        }
        return true;
    }

    return mCryptex9.UnsealData(pSource,
                               SOCCER_SCRATCH_WORKER_A,
                               SOCCER_WORKER_B,
                               pDestination,
                               SOCCER_BLOCK_SIZE,
                               nullptr);
}

bool Soccer2::SeedPrelude_Test(std::uint8_t *pPassword,
                               std::size_t pPasswordByteLength,
                               std::uint64_t pNonce) {
    
    UnrollNonceAndPasswordToScratch_Test(pPassword, pPasswordByteLength, pNonce);
    
    std::uint64_t aValue = 0x00;
    for (std::size_t aIndex=0; aIndex<SOCCER_BLOCK_SIZE; aIndex++) {
        aValue = RotL64(aValue, 3);
        aValue ^= static_cast<std::uint64_t>(SOCCER_SCRATCH_WORKER_A[aIndex]);
        aValue = (aValue * 3333333333333333333ULL);
        mMaterialA[aIndex] = static_cast<std::uint8_t>(aValue);
    }
    
    return true;
}

void Soccer2::SeedPrelude_Regular_A(std::uint8_t *pPassword,
                                    std::size_t pPasswordByteLength,
                                    std::uint64_t pNonce) {
    
    InitializeExpanders();
    InitializeWorkSpaces();
    InitializeMaterials();
    InitializeCiphers();
    
    memset(mClaimedExpanders, 0, sizeof(mClaimedExpanders));
    mClaimedExpanderCount = 0;
    
    memset(mClaimedMaterials, 0, sizeof(mClaimedMaterials));
    mClaimedMaterialCount = 0;
    
    memset(mClaimedWorkSpaces, 0, sizeof(mClaimedWorkSpaces));
    mClaimedWorkSpaceCount = 0;
    
    UnrollNonceAndPasswordToScratch_Regular(pPassword, pPasswordByteLength, pNonce);
}

void Soccer2::SeedPrelude_Regular_B(std::uint64_t pNonce, MUTABLE_PARAMS) {
    
    READ_IN_MUTABLE_PARAMS_INTERNAL;
    
    mStarter.Seed(&mWorkSpaceA, pNonce, SOCCER_SCRATCH_WORKER_A, S_BLOCK, mCollapseLaneB, ARX_STATE_VARS);
    AdvanceSeedProgress(kExpanderSeedCost);
    
    WRITE_OUT_MUTABLE_PARAMS;
}

void Soccer2::SeedPrelude_Regular_C() {
    // Cipher pools use the first three quarters of each cipher-shuffle span.
    TwistShuffle::ShuffleList32(mCiphersMutate,           SOCCER_PRELUDE_RAND,     0U,  1024U, 4U);
    TwistShuffle::ShuffleList32(mCiphersPrimaryMovers,    SOCCER_PRELUDE_RAND,  1024U,  2048U, 4U);
    TwistShuffle::ShuffleList32(mCiphersSecondaryMovers,  SOCCER_PRELUDE_RAND,  2048U,  3072U, 4U);
    TwistShuffle::ShuffleList16(mExpanders,     SOCCER_PRELUDE_RAND,  4096,  8192, 4);
    TwistShuffle::ShuffleList16(mWorkSpaces,    SOCCER_PRELUDE_RAND,  8192, 12288, 4);
    TwistShuffle::ShuffleList16(mMaterials,     SOCCER_PRELUDE_RAND, 12288, 16384, 4);
    
    TwistShuffle::ShuffleList32(mCiphersMutate,           SOCCER_PRELUDE_RAND, 16384U, 17408U, 4U);
    TwistShuffle::ShuffleList32(mCiphersPrimaryMovers,    SOCCER_PRELUDE_RAND, 17408U, 18432U, 4U);
    TwistShuffle::ShuffleList32(mCiphersSecondaryMovers,  SOCCER_PRELUDE_RAND, 18432U, 19456U, 4U);
    TwistShuffle::ShuffleList16(mExpanders,     SOCCER_PRELUDE_RAND, 20480, 24576, 4);
    TwistShuffle::ShuffleList16(mWorkSpaces,    SOCCER_PRELUDE_RAND, 24576, 28672, 4);
    TwistShuffle::ShuffleList16(mMaterials,     SOCCER_PRELUDE_RAND, 28672, 32768, 4);
}

void Soccer2::SeedEpilogue_Regular_A() {
    const std::uint8_t *aShrinkSourceA = nullptr;
    const std::uint8_t *aShrinkSourceB = nullptr;
    const std::uint8_t *aShrinkSourceC = nullptr;
    const std::uint8_t *aShrinkSourceD = nullptr;
    
    if (mStrength == EncryptionStrength::kWeak) {
        aShrinkSourceA = mMaterials[0];
        aShrinkSourceB = mMaterials[1];
        aShrinkSourceC = mMaterials[2];
        aShrinkSourceD = mMaterials[3];
    } else if (mStrength == EncryptionStrength::kStrong) {
        SoccerFolding::Collapse_Stage3_Outer_16(mMaterials[0], mMaterials[1], mMaterials[2], mMaterials[3],
                                                mMaterials[4], mMaterials[5], mMaterials[6], mMaterials[7],
                                                mMaterials[8], mMaterials[9], mMaterials[10], mMaterials[11],
                                                mMaterials[12], mMaterials[13], mMaterials[14], mMaterials[15],
                                                mCollapseLaneA, mCollapseLaneB, mCollapseLaneC, mCollapseLaneD);
        
        aShrinkSourceA = mCollapseLaneA;
        aShrinkSourceB = mCollapseLaneB;
        aShrinkSourceC = mCollapseLaneC;
        aShrinkSourceD = mCollapseLaneD;
    } else {
        SoccerFolding::Collapse_Stage3_Outer_8(mMaterials[0], mMaterials[1], mMaterials[2], mMaterials[3],
                                               mMaterials[4], mMaterials[5], mMaterials[6], mMaterials[7],
                                               mCollapseLaneA, mCollapseLaneB, mCollapseLaneC, mCollapseLaneD);
        
        aShrinkSourceA = mCollapseLaneA;
        aShrinkSourceB = mCollapseLaneB;
        aShrinkSourceC = mCollapseLaneC;
        aShrinkSourceD = mCollapseLaneD;
    }
    
    SoccerFolding::Collapse_Stage2_4(aShrinkSourceA, aShrinkSourceB, aShrinkSourceC, aShrinkSourceD,
                                     mCondenseLaneA, mCondenseLaneB, mCondenseLaneC, mCondenseLaneD);
    
    // Shrink has consumed the collapse lanes, so alternate back into them.
    SoccerFolding::Collapse_Stage1_4(mCondenseLaneA, mCondenseLaneB, mCondenseLaneC, mCondenseLaneD,
                                     mCollapseLaneA, mCollapseLaneB, mCollapseLaneC, mCollapseLaneD);
    
    // Compress has consumed the shrink lanes; they now hold the final crush material.
    SoccerFolding::Collapse_Stage0_4(mCollapseLaneA, mCollapseLaneB, mCollapseLaneC, mCollapseLaneD,
                                     mCondenseLaneA, mCondenseLaneB, mCondenseLaneC, mCondenseLaneD);
    
    mMaterialIndex = 0;
    mMaterialQuarter = 0;
    
    mMaskCursor = 0;
}

std::uint64_t Soccer2::ReadShuffleWord(std::size_t pIndex) {
    using Layout = PremiumSeedLayout;
    assert(pIndex < Layout::kShuffleWords);
    const std::uint8_t *aLanes[] = {mCondenseLaneA, mCondenseLaneB, mCondenseLaneC, mCondenseLaneD};
    const auto aPhysical = Layout::ShuffleWordIndex(pIndex);
    return TwistMix64::DiffuseA(Load64LE(aLanes[aPhysical / Layout::kWordsPerLane] +
                                       (aPhysical % Layout::kWordsPerLane) * 8U));
}

void Soccer2::SeedEpilogue_Regular_B() {
    using Layout = PremiumSeedLayout;
    static_assert(Layout::kLaneBytes == SOCCER_BLOCK_SIZE_C1);
    const std::uint8_t *aLanes[] = {mCondenseLaneA, mCondenseLaneB, mCondenseLaneC, mCondenseLaneD};
    for (std::size_t i = 0U; i < kSeedIndexCount; ++i) {
        mIndexListA[i] = static_cast<std::uint16_t>(i);
        mIndexListB[i] = static_cast<std::uint16_t>(i);
    }
    for (std::size_t i = 0U; i < Layout::kIndexShuffleEnd; ++i) {
        auto aWord = ReadShuffleWord(i);
        auto *aIndices = (i & 1U) == 0U ? mIndexListA : mIndexListB;
        for (unsigned aSwap = 0U; aSwap < 2U; ++aSwap) {
            const auto aIndexA = aWord % kSeedIndexCount; aWord /= kSeedIndexCount;
            const auto aIndexB = aWord % kSeedIndexCount; aWord /= kSeedIndexCount;
            std::swap(aIndices[aIndexA], aIndices[aIndexB]);
        }
    }
    // Every source word contributes to exactly one 48-word fold, including
    // the middle fold that crosses the two index streams.
    static_assert(2U * kSeedIndexCount == kPremiumSeedWordCount * Layout::kFoldWords);
    for (std::size_t aOutput = 0U; aOutput < kPremiumSeedWordCount; ++aOutput) {
        std::uint64_t aFold = 0ULL;
        for (std::size_t i = 0U; i < Layout::kFoldWords; ++i) {
            const auto aPosition = aOutput * Layout::kFoldWords + i;
            const auto aSource = aPosition < kSeedIndexCount ? mIndexListA[aPosition] :
                kSeedIndexCount + mIndexListB[aPosition - kSeedIndexCount];
            const auto aPhysical = Layout::SeedWordIndex(aSource);
            const auto aWord = Load64LE(aLanes[aPhysical / Layout::kWordsPerLane] +
                                       (aPhysical % Layout::kWordsPerLane) * 8U);
            aFold = TwistMix64::DiffuseA(aFold ^ aWord);
        }
        mPremiumSeed[aOutput] = aFold;
    }
    for (std::size_t i = Layout::kIndexShuffleEnd; i < Layout::kPremiumShuffleEnd; ++i) {
        const auto aWord = ReadShuffleWord(i);
        std::swap(mPremiumSeed[static_cast<std::uint32_t>(aWord) % kPremiumSeedWordCount],
                  mPremiumSeed[static_cast<std::uint32_t>(aWord >> 32U) % kPremiumSeedWordCount]);
    }
}

void Soccer2::SelectRotationWindows() {
    static_assert(kRotationWindowCount * 3U < kRotationWindowBaseCount);
    std::fill_n(mRotationWindow, kRotationWindowCount, std::uint16_t{0U});
    std::fill_n(mRotationWindowBlockList, kRotationWindowBlockCapacity, std::uint16_t{0U});
    mRotationWindowBlockListCount = mRotationWindowBaseReadCount = 0U;
    const auto aBlocked = [](std::uint16_t pValue) {
        return std::find(mRotationWindowBlockList,
                         mRotationWindowBlockList + mRotationWindowBlockListCount, pValue) !=
               mRotationWindowBlockList + mRotationWindowBlockListCount;
    };
    std::size_t aCount = 0U;
    while (aCount < kRotationWindowCount && mRotationWindowBaseReadCount < kRotationWindowBaseCount) {
        const auto aWindow = mRotationWindowBase[mRotationWindowBaseReadCount++];
        if (aWindow == 0U || aBlocked(aWindow)) { continue; }
        mRotationWindow[aCount++] = aWindow;
        for (auto aValue : {aWindow, static_cast<std::uint16_t>(4096U - aWindow),
                           static_cast<std::uint16_t>(4095U - aWindow)}) {
            if (aValue != 0U && !aBlocked(aValue)) {
                mRotationWindowBlockList[mRotationWindowBlockListCount++] = aValue;
            }
        }
    }
    // A valid permutation always supplies 256 choices: at most three values
    // are excluded per choice, well below the 4,095 available values.
    assert(aCount == kRotationWindowCount);
}

void Soccer2::FarmRotationWindows() {
    using Layout = PremiumSeedLayout;
    static_assert(SOCCER_BLOCK_SIZE_L1 / 64U == 4096U);
    static_assert(Layout::kRotationShuffleEnd - Layout::kRotationShuffleBegin == kRotationWindowBaseCount - 1U);
    for (std::size_t i = 0U; i < kRotationWindowBaseCount; ++i) {
        mRotationWindowBase[i] = static_cast<std::uint16_t>(i + 1U);
    }
    // Full Fisher-Yates permutation. Every swap gets a separate full 64-bit
    // material word; modulo reduction has only the 64-bit remainder bias.
    auto aWordIndex = Layout::kRotationShuffleBegin;
    for (std::size_t i = kRotationWindowBaseCount - 1U; i > 0U; --i) {
        const auto aSwap = ReadShuffleWord(aWordIndex++) % (i + 1U);
        std::swap(mRotationWindowBase[i], mRotationWindowBase[aSwap]);
    }
    SelectRotationWindows();
    for (std::size_t i = 0U; i < kRotationWindowListCount; ++i) {
        mRotationWindowListL1[i] = mRotationWindow[i];
        mRotationWindowListL2[i] = static_cast<std::uint16_t>(mRotationWindow[64U + i] +
            4096U * (ReadShuffleWord(Layout::kRotationLiftL2Begin + i) % 2U));
        mRotationWindowListL3[i] = static_cast<std::uint16_t>(mRotationWindow[128U + i] +
            4096U * (ReadShuffleWord(Layout::kRotationLiftL3Begin + i) % 4U));
        const auto aFreeWindow = mRotationWindow[192U + i] +
            4096U * (ReadShuffleWord(Layout::kRotationFreeLiftBegin + i) % 4U);
        const auto aByteOffset = 1U + ReadShuffleWord(Layout::kRotationFreeByteBegin + i) % 63U;
        mRotationWindowListFree[i] = static_cast<std::int32_t>(aFreeWindow * 64U + aByteOffset);
    }
}

void Soccer2::AssignRotationWindows() {
    static_assert(kByteRotationCount <= kRotationWindowListCount);
    static_assert(48U <= kRotationWindowListCount);
    const std::uint16_t *aLists[] = {mRotationWindowListL3, mRotationWindowListL2, mRotationWindowListL1};
    std::size_t aFrogNext[] = {0U, 0U, 0U};
    for (std::size_t aStage = 0U; aStage < kSamplingStageCount; ++aStage) {
        const auto aLevel = aStage % 3U;
        for (std::size_t aPass = 0U; aPass < 2U; ++aPass) {
            for (std::size_t aGroup = 0U; aGroup < 3U; ++aGroup) {
                auto &aInput = mBitPlaneInputs[aStage][aPass][aGroup];
                aInput = {};
                const auto aMask = mBitPlanes[aLevel][aPass][aGroup];
                for (std::uint8_t aRow = 0U; aRow < 8U; ++aRow) {
                    if ((aMask & (1U << aRow)) == 0U) { continue; }
                    assert(aInput.mCount < 3U && aFrogNext[aLevel] < kRotationWindowListCount);
                    // Follow the two preceding full-byte rotations within
                    // this L3/L2/L1 group. Reset the mask orientation in A/B/C.
                    // Keep each offset paired with its original sampled row.
                    aInput.mRows[aInput.mCount] = static_cast<std::uint8_t>((aRow + 3U * aLevel) % 8U);
                    aInput.mRotations[aInput.mCount++] = aLists[aLevel][aFrogNext[aLevel]++];
                }
                assert(aInput.mCount == (aGroup == aLevel ? 2U : 3U));
            }
        }
    }
    // Legacy Planet/Moon/Star factory inputs remain available for experiments.
    // These aliases are not used by the active plan and consume no extra slots.
    std::size_t aNext[] = {0U, 0U, 0U};
    std::int32_t *aBytes[] = {mRotationsByteL3, mRotationsByteL2, mRotationsByteL1};
    for (std::size_t aStage = 0U; aStage < kSamplingStageCount; ++aStage) {
        const auto aLevel = aStage % 3U;
        for (const auto *aInputs : {mPlanetInputs, mMoonInputs, mStarInputs}) {
            const auto &aInput = aInputs[aStage];
            for (std::size_t i = 0U; i < aInput.mCount; ++i) {
                aInput.mRotations[i] = aLists[aLevel][aNext[aLevel]++];
            }
        }
        for (std::size_t aSlot = 0U; aSlot < kRotationsPerLayer; ++aSlot) {
            aBytes[aLevel][aSlot * 3U + aStage / 3U] =
                mRotationWindowListFree[aStage * kRotationsPerLayer + aSlot] % (SOCCER_BLOCK_SIZE >> aLevel);
        }
    }
}

void Soccer2::FarmBitPlanes() {
    mBitPlanes = BitPlaneFarm::Select(mBitPlaneSelectionValues[0],
                                    mBitPlaneSelectionValues[1],
                                    mBitPlaneSelectionValues[2]);
}

void Soccer2::SeedEpilogue_Regular_C() {
    using Layout = PremiumSeedLayout;
    static_assert(3U * kSamplingWordsPerGroup == kPremiumSeedWordCount);
    FarmBitPlanes();
    FarmRotationWindows();
    AssignRotationWindows();
    mPlanSelectionValue = ReadShuffleWord(Layout::kPlanSelectionIndex);

    // The premium seed is used ONLY for row-family grids and row ordering.
    std::size_t aPremiumIndex = 0U;
    const SamplingInput *aBanks[] = {mPlanetInputs, mMoonInputs, mStarInputs};
    for (std::size_t aGroup = 0U; aGroup < 3U; ++aGroup) {
        const auto aFirstPass = TwistMix64::DiffuseA(mPremiumSeed[aPremiumIndex++]);
        const auto aSecondPass = TwistMix64::DiffuseA(mPremiumSeed[aPremiumIndex++]);
        const auto aCompletion = TwistMix64::DiffuseA(mPremiumSeed[aPremiumIndex++]);
        const auto aGrid = SamplingTriplet::Select(aFirstPass, aSecondPass, aCompletion);
        for (unsigned aLevel = 0U; aLevel < 3U; ++aLevel) {
            const auto aStage = aGroup * 3U + aLevel;
            for (unsigned aBank = 0U; aBank < 3U; ++aBank) {
                const auto aSelected = aGrid[aLevel][(aBank + 3U - aGroup) % 3U];
                const auto &aInput = aBanks[aBank][aStage];
                const auto aOrderFirst = TwistMix64::DiffuseA(mPremiumSeed[aPremiumIndex++]);
                const auto aOrderSecond = TwistMix64::DiffuseA(mPremiumSeed[aPremiumIndex++]);
                SamplingTriplet::OrderRows(aSelected, aOrderFirst, aOrderSecond, aInput.mRows);
            }
        }
    }
    assert(aPremiumIndex == kPremiumSeedWordCount);

    const auto aMaskListIndex = ReadShuffleWord(Layout::kMaskSelectionIndex) % SoccerMaskBank::mMaskGridHeight;
    std::copy_n(SoccerMaskBank::mMaskGrid[aMaskListIndex], SoccerMaskBank::mMaskGridWidth, mMasks);
    const std::size_t aMaterialCount = mStrength == EncryptionStrength::kWeak ? 4U :
                                     mStrength == EncryptionStrength::kStrong ? 16U : 8U;
    const auto aMaterialIndexMask = aMaterialCount - 1U;
    for (std::size_t i = Layout::kMaterialShuffleBegin; i < Layout::kMaterialShuffleEnd; ++i) {
        const auto aWord = ReadShuffleWord(i);
        std::swap(mMaterials[static_cast<std::uint32_t>(aWord) & aMaterialIndexMask],
                  mMaterials[static_cast<std::uint32_t>(aWord >> 32U) & aMaterialIndexMask]);
    }
    const std::size_t aReverseCount = aMaterialCount / 2U;
    bool aReverseMaterial[16] = {};
    for (std::size_t i = 0U; i < aReverseCount; ++i) {
        aReverseMaterial[ReadShuffleWord(Layout::kMaterialReverseBegin + i) & aMaterialIndexMask] = true;
    }
    for (std::size_t i = 0U; i < aMaterialCount; ++i) {
        if (aReverseMaterial[i]) { std::reverse(mMaterials[i], mMaterials[i] + SOCCER_BLOCK_SIZE); }
    }
    // Weak/normal's unused reversal words also shuffle masks.
    for (std::size_t i = Layout::kMaterialReverseBegin + aReverseCount; i < Layout::kMaskShuffleEnd; ++i) {
        const auto aWord = ReadShuffleWord(i);
        std::swap(mMasks[static_cast<std::uint32_t>(aWord) % SoccerMaskBank::mMaskGridWidth],
                  mMasks[static_cast<std::uint32_t>(aWord >> 32U) % SoccerMaskBank::mMaskGridWidth]);
    }

    // All mask shuffles are complete. Rotate the actual masks consumed by the
    // selected plan, accounting for construction order rather than execution.
    const auto aPlan = EncryptionPlanTool::MakePlan(mStrength, mPlanSelectionValue,
        mCiphersMutate, mCiphersPrimaryMovers, mCiphersSecondaryMovers);
    const bool aMasksRotated = EncryptionPlanTool::RotateMasksForPlan(
        aPlan, mMasks, SoccerMaskBank::mMaskGridWidth);
    assert(aMasksRotated);
    (void)aMasksRotated; // In release builds, D also rejects an overdraw before allocation.
}

bool Soccer2::SeedEpilogue_Regular_D() {
    const std::uint64_t aPlanSelect = mPlanSelectionValue;

    const EncryptionPlan aPlan = EncryptionPlanTool::MakePlan(mStrength, aPlanSelect,
        mCiphersMutate, mCiphersPrimaryMovers, mCiphersSecondaryMovers);

    // Reject an overdraw before allocating ciphers. PopMask wraps its cursor,
    // so counting the plan here prevents accidentally reusing a bank entry.
    const EncryptionPlanStage *aStages[] = {&aPlan.mL3A, &aPlan.mL3B, &aPlan.mL3C,
        &aPlan.mL2A, &aPlan.mL2B, &aPlan.mL2C, &aPlan.mL1A, &aPlan.mL1B, &aPlan.mL1C};
    std::size_t aMaskCount = 0U, aMaterialQuarters = 0U;
    for (std::size_t aStage = 0U; aStage < 9U; ++aStage) {
        const auto &aLayer = *aStages[aStage];
        if (aLayer.mCount == 0U || aLayer.mCount > sizeof(aLayer.mType) / sizeof(aLayer.mType[0])) {
            return false;
        }
        const auto aQuartersPerLane = 4U >> (aStage / 3U);
        std::size_t aRotationCount = 0U;
        for (std::size_t i = 0U; i < aLayer.mCount; ++i) {
            if (IS_ROTATION_ANY(aLayer.mType[i])) {
                if (aLayer.mType[i] != CipherType::kRotateMaskCipher ||
                    aLayer.mSamplingBank[i] != CipherSamplingBank::kBitPlaneFirstA ||
                    aLayer.mRotationIndex[i] != 0U) { return false; }
                ++aRotationCount;
            }
            aMaskCount += IS_MASKED(aLayer.mType[i]) && !IsBitPlaneMaskBank(aLayer.mSamplingBank[i]);
            aMaterialQuarters += CipherTool::CountLanes(aLayer.mType[i]) * aQuartersPerLane;
        }
        if (aRotationCount != 1U) { return false; }
    }
    const std::size_t aMaterialBudget = mStrength == EncryptionStrength::kWeak ? 16U
                                    : mStrength == EncryptionStrength::kStrong ? 64U : 32U;
    if (aMaskCount > SoccerMaskBank::mMaskGridWidth || aMaterialQuarters > aMaterialBudget) {
        return false;
    }
    // Every parameter is addressed by its layer. No rotation/offset cursors.
    // Consume key material in descending lane size so the quarter-lane cursor
    // does not strand material needed by a larger lane.
    for (std::size_t aCipherIndex=0U; aCipherIndex<aPlan.mL3A.mCount; aCipherIndex++) {
        Cipher *aCipher = GenerateCipher(aPlan.mL3A.mType[aCipherIndex], kStageL3A,
                                         aPlan.mL3A.mSamplingBank[aCipherIndex],
                                         aPlan.mL3A.mRotationIndex[aCipherIndex]);
        if (aCipher == nullptr) {
            return false;
        }
        mCryptex9.AddCipherL3A(aCipher);
    }
    
    for (std::size_t aCipherIndex=0U; aCipherIndex<aPlan.mL3B.mCount; aCipherIndex++) {
        Cipher *aCipher = GenerateCipher(aPlan.mL3B.mType[aCipherIndex], kStageL3B,
                                         aPlan.mL3B.mSamplingBank[aCipherIndex],
                                         aPlan.mL3B.mRotationIndex[aCipherIndex]);
        if (aCipher == nullptr) {
            return false;
        }
        mCryptex9.AddCipherL3B(aCipher);
    }
    
    for (std::size_t aCipherIndex=0U; aCipherIndex<aPlan.mL3C.mCount; aCipherIndex++) {
        Cipher *aCipher = GenerateCipher(aPlan.mL3C.mType[aCipherIndex], kStageL3C,
                                         aPlan.mL3C.mSamplingBank[aCipherIndex],
                                         aPlan.mL3C.mRotationIndex[aCipherIndex]);
        if (aCipher == nullptr) {
            return false;
        }
        mCryptex9.AddCipherL3C(aCipher);
    }
    
    for (std::size_t aCipherIndex=0U; aCipherIndex<aPlan.mL2A.mCount; aCipherIndex++) {
        Cipher *aCipher = GenerateCipher(aPlan.mL2A.mType[aCipherIndex], kStageL2A,
                                         aPlan.mL2A.mSamplingBank[aCipherIndex],
                                         aPlan.mL2A.mRotationIndex[aCipherIndex]);
        if (aCipher == nullptr) {
            return false;
        }
        mCryptex9.AddCipherL2A(aCipher);
    }
    
    for (std::size_t aCipherIndex=0U; aCipherIndex<aPlan.mL2B.mCount; aCipherIndex++) {
        Cipher *aCipher = GenerateCipher(aPlan.mL2B.mType[aCipherIndex], kStageL2B,
                                         aPlan.mL2B.mSamplingBank[aCipherIndex],
                                         aPlan.mL2B.mRotationIndex[aCipherIndex]);
        if (aCipher == nullptr) {
            return false;
        }
        mCryptex9.AddCipherL2B(aCipher);
    }
    
    for (std::size_t aCipherIndex=0U; aCipherIndex<aPlan.mL2C.mCount; aCipherIndex++) {
        Cipher *aCipher = GenerateCipher(aPlan.mL2C.mType[aCipherIndex], kStageL2C,
                                         aPlan.mL2C.mSamplingBank[aCipherIndex],
                                         aPlan.mL2C.mRotationIndex[aCipherIndex]);
        if (aCipher == nullptr) {
            return false;
        }
        mCryptex9.AddCipherL2C(aCipher);
    }
    
    for (std::size_t aCipherIndex=0U; aCipherIndex<aPlan.mL1A.mCount; aCipherIndex++) {
        Cipher *aCipher = GenerateCipher(aPlan.mL1A.mType[aCipherIndex], kStageL1A,
                                         aPlan.mL1A.mSamplingBank[aCipherIndex],
                                         aPlan.mL1A.mRotationIndex[aCipherIndex]);
        if (aCipher == nullptr) {
            return false;
        }
        mCryptex9.AddCipherL1A(aCipher);
    }
    
    for (std::size_t aCipherIndex=0U; aCipherIndex<aPlan.mL1B.mCount; aCipherIndex++) {
        Cipher *aCipher = GenerateCipher(aPlan.mL1B.mType[aCipherIndex], kStageL1B,
                                         aPlan.mL1B.mSamplingBank[aCipherIndex],
                                         aPlan.mL1B.mRotationIndex[aCipherIndex]);
        if (aCipher == nullptr) {
            return false;
        }
        mCryptex9.AddCipherL1B(aCipher);
    }
    
    for (std::size_t aCipherIndex=0U; aCipherIndex<aPlan.mL1C.mCount; aCipherIndex++) {
        Cipher *aCipher = GenerateCipher(aPlan.mL1C.mType[aCipherIndex], kStageL1C,
                                         aPlan.mL1C.mSamplingBank[aCipherIndex],
                                         aPlan.mL1C.mRotationIndex[aCipherIndex]);
        if (aCipher == nullptr) {
            return false;
        }
        mCryptex9.AddCipherL1C(aCipher);
    }
    
    return true;
}

void Soccer2::Shuffle_MEWBlockZero(std::uint8_t *pMaterial) {
    
    for (std::size_t aIndex=0; aIndex<16; aIndex++) {
        mShuffleMaterials[aIndex] = mMaterials[aIndex];
    }
    for (std::size_t aIndex=0; aIndex<SOCCER_EXPANDER_COUNT; aIndex++) {
        mShuffleExpanders[aIndex] = mExpanders[aIndex];
    }
    for (std::size_t aIndex=0; aIndex<16; aIndex++) {
        mShuffleWorkSpaces[aIndex] = mWorkSpaces[aIndex];
    }
    
    TwistShuffle::ShuffleList16(mShuffleMaterials,  pMaterial,     0U,  3600U, 1U);
    TwistShuffle::ShuffleList16(mShuffleExpanders,  pMaterial,  3600U,  7200U, 1U);
    TwistShuffle::ShuffleList16(mShuffleWorkSpaces, pMaterial,  7200U, 10800U, 1U);

    TwistShuffle::ShuffleList16(mShuffleMaterials,  pMaterial, 10800U, 14400U, 1U);
    TwistShuffle::ShuffleList16(mShuffleExpanders,  pMaterial, 14400U, 18000U, 1U);
    TwistShuffle::ShuffleList16(mShuffleWorkSpaces, pMaterial, 18000U, 21600U, 1U);

    TwistShuffle::ShuffleList16(mShuffleMaterials,  pMaterial, 21600U, 25200U, 1U);
    TwistShuffle::ShuffleList16(mShuffleExpanders,  pMaterial, 25200U, 28800U, 1U);
    TwistShuffle::ShuffleList16(mShuffleWorkSpaces, pMaterial, 28800U, 32400U, 1U);

    // Move claimed materials to the back.
    for (std::size_t aIndex=0; aIndex<16; aIndex++) {
        mClaimed[aIndex] = false;
        for (std::size_t aClaimedIndex=0; aClaimedIndex<mClaimedMaterialCount; aClaimedIndex++) {
            if (mShuffleMaterials[aIndex] == mClaimedMaterials[aClaimedIndex]) {
                mClaimed[aIndex] = true;
                break;
            }
        }
    }

    TwistShuffle::MoveClaimedToEnd16(mClaimed, mShuffleMaterials);

    // Move claimed expanders to the back.
    for (std::size_t aIndex=0; aIndex<SOCCER_EXPANDER_COUNT; aIndex++) {
        mClaimed[aIndex] = false;
        for (std::size_t aClaimedIndex=0; aClaimedIndex<mClaimedExpanderCount; aClaimedIndex++) {
            if (mShuffleExpanders[aIndex] == mClaimedExpanders[aClaimedIndex]) {
                mClaimed[aIndex] = true;
                break;
            }
        }
    }

    TwistShuffle::MoveClaimedToEnd16(mClaimed, mShuffleExpanders);

    // Move claimed work spaces to the back.
    for (std::size_t aIndex=0; aIndex<16; aIndex++) {
        mClaimed[aIndex] = false;
        for (std::size_t aClaimedIndex=0; aClaimedIndex<mClaimedWorkSpaceCount; aClaimedIndex++) {
            if (mShuffleWorkSpaces[aIndex] == mClaimedWorkSpaces[aClaimedIndex]) {
                mClaimed[aIndex] = true;
                break;
            }
        }
    }

    TwistShuffle::MoveClaimedToEnd16(mClaimed, mShuffleWorkSpaces);

    for (std::size_t aIndex=0; aIndex<16; aIndex++) {
        mMaterials[aIndex] = mShuffleMaterials[aIndex];
    }
    for (std::size_t aIndex=0; aIndex<SOCCER_EXPANDER_COUNT; aIndex++) {
        mExpanders[aIndex] = mShuffleExpanders[aIndex];
    }
    for (std::size_t aIndex=0; aIndex<16; aIndex++) {
        mWorkSpaces[aIndex] = mShuffleWorkSpaces[aIndex];
    }
}
